// 函数: _Z10CountPilesP11DomCardEnum
// 地址: 0xa2fbb8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

if (*arg1 == 0)
    return 0

if (*(arg1 + 4) == 0)
    return 1

if (*(arg1 + 8) == 0)
    return 2

if (*(arg1 + 0xc) == 0)
    return 3

if (*(arg1 + 0x10) == 0)
    return 4

if (*(arg1 + 0x14) == 0)
    return 5

if (*(arg1 + 0x18) == 0)
    return 6

if (*(arg1 + 0x1c) == 0)
    return 7

if (*(arg1 + 0x20) == 0)
    return 8

if (*(arg1 + 0x24) == 0)
    return 9

if (*(arg1 + 0x28) == 0)
    return 0xa

if (*(arg1 + 0x2c) == 0)
    return 0xb

if (*(arg1 + 0x30) == 0)
    return 0xc

if (*(arg1 + 0x34) == 0)
    return 0xd

if (*(arg1 + 0x38) == 0)
    return 0xe

if (*(arg1 + 0x3c) == 0)
    return 0xf

if (*(arg1 + 0x40) == 0)
    return 0x10

if (*(arg1 + 0x44) == 0)
    return 0x11

if (*(arg1 + 0x48) == 0)
    return 0x12

if (*(arg1 + 0x4c) == 0)
    return 0x13

if (*(arg1 + 0x50) == 0)
    return 0x14

if (*(arg1 + 0x54) == 0)
    return 0x15

if (*(arg1 + 0x58) == 0)
    return 0x16

if (*(arg1 + 0x5c) == 0)
    return 0x17

if (*(arg1 + 0x60) == 0)
    return 0x18

if (*(arg1 + 0x64) != 0)
    return 0x1a

return 0x19
