// 函数: _Z10Collectionv
// 地址: 0xab4f08
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

MoneyTreasure(2, 0)
Buy(1, 0)
return ThisTurnRepeated(6, sub_ab54a4, sub_ab54c0, 2, 1) __tailcall
