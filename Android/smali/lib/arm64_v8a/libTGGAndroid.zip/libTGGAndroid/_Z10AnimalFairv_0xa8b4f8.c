// 函数: _Z10AnimalFairv
// 地址: 0xa8b4f8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

MoneyPlus(4, 0, false)
return Buy(CountEmptySupplyPiles(), 0) __tailcall
