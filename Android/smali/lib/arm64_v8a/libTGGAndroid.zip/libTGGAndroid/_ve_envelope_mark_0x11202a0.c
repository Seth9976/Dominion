// 函数: _ve_envelope_mark
// 地址: 0x11202a0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _ve_envelope_mark() __tailcall
