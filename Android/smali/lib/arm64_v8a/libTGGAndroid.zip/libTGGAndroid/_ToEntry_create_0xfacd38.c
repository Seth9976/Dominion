// 函数: _ToEntry_create
// 地址: 0xfacd38
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t* result =
    _spCalloc(1, 0x18, "..\..\ExternalCode\spine-c\src\spine\AnimationStateData.c", 0x29)
*result = arg1
result[1].d = arg2
return result
