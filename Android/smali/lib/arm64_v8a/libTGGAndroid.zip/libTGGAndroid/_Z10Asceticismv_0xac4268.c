// 函数: _Z10Asceticismv
// 地址: 0xac4268
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t x0 = CountMoney()
int32_t x19_1 = CountCoffers() + x0

if (CountWhere(0x3ea) s< x19_1)
    x19_1 = CountWhere(0x3ea)

return TrashUpTo(x19_1, 0x12b, 0, sub_acabd0)
