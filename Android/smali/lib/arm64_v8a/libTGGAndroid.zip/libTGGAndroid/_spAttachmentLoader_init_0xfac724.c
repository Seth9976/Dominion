// 函数: _spAttachmentLoader_init
// 地址: 0xfac724
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* result = _spCalloc(1, 0x20, "..\..\ExternalCode\spine-c\src\spine\AttachmentLoader.c", 0x30)
*(arg1 + 0x10) = result
*(result + 0x18) = arg2
**(arg1 + 0x10) = arg3
*(*(arg1 + 0x10) + 8) = arg4
*(*(arg1 + 0x10) + 0x10) = arg5
return result
