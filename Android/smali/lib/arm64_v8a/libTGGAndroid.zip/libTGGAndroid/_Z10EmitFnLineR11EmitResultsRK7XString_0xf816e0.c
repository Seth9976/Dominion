// 函数: _Z10EmitFnLineR11EmitResultsRK7XString
// 地址: 0xf816e0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x19 = arg1 + (sx.q(*(arg1 + (sx.q(*(arg1 + 0x24c)) << 2) + 0x208)) << 4) + 0x10
XString::operator+(arg2)
XString::operator=(x19)
return XString::~XString()
