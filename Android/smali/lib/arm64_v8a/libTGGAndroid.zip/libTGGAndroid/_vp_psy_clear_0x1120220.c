// 函数: _vp_psy_clear
// 地址: 0x1120220
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _vp_psy_clear() __tailcall
