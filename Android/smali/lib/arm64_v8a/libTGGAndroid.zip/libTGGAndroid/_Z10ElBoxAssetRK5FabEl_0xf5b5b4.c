// 函数: _Z10ElBoxAssetRK5FabEl
// 地址: 0xf5b5b4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return ElBox(arg1, 0x864c78) __tailcall
