// 函数: _Z10Bell_Twistv
// 地址: 0xa349cc
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return CampaignAddTwist(RollTwist()) __tailcall
