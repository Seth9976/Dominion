// 函数: _spVertexAttachment_init
// 地址: 0xfb741c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t x9 = data_242258c
data_242258c = x9 + 1
*(arg1 + 0x58) = (x9 & 0xffff) << 0xb
*(arg1 + 0x50) = arg1
