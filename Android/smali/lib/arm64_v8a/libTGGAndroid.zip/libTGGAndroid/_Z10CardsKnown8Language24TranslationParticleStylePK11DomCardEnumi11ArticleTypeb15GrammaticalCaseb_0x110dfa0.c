// 函数: _Z10CardsKnown8Language24TranslationParticleStylePK11DomCardEnumi11ArticleTypeb15GrammaticalCaseb
// 地址: 0x110dfa0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return CardsKnown(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) __tailcall
