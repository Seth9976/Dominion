// 函数: _FromEntry_create
// 地址: 0xfacd78
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t* result =
    _spCalloc(1, 0x18, "..\..\ExternalCode\spine-c\src\spine\AnimationStateData.c", 0x3d)
*result = arg1
return result
