// 函数: _FromEntry_dispose
// 地址: 0xfacda4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _spFree() __tailcall
