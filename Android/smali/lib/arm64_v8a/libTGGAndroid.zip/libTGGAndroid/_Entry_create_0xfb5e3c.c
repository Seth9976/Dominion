// 函数: _Entry_create
// 地址: 0xfb5e3c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t* result = _spCalloc(1, 0x20, "..\..\ExternalCode\spine-c\src\spine\Skin.c", 0x28)
*result = arg1
int64_t x0_3 = _spMalloc(strlen(arg2) + 1, "..\..\ExternalCode\spine-c\src\spine\Skin.c", 0x2a)
*(result + 8) = x0_3
strcpy(x0_3, arg2)
*(result + 0x10) = arg3
return result
