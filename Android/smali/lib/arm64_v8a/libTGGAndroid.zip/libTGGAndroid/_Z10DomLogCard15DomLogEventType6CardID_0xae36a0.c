// 函数: _Z10DomLogCard15DomLogEventType6CardID
// 地址: 0xae36a0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t var_14 = arg2
void* x0 = DomGetContext()
int32_t var_28 = 0
int32_t var_30 = 0
return NotifyLog(*(x0 + 8), zx.q(arg1), zx.q(*(x0 + 0x18)), 0, &var_14, 1, 0, 0)
