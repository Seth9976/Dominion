// 函数: _spAnimationState_disposeNext
// 地址: 0xfbbd64
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

for (void* i = *(arg2 + 8); i != 0; i = *(i + 8))
    _spEventQueue_dispose(*(arg1 + 0x48), i)

*(arg2 + 8) = 0
