// 函数: _Z10EndingIsVCRK7XStringRS_S2_
// 地址: 0xf7869c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t x0_1 = UTF8Length(XString::operator char const*())
UTF8At(XString::operator char const*(), x0_1 - 2)
XString::operator=(arg2)
XString::~XString()
UTF8At(XString::operator char const*(), x0_1 - 1)
XString::operator=(arg3)
XString::~XString()
char* needle = XString::operator char const*()
UTF8Length(needle)

if (strstr("aeiou", needle) != 0)
    char* needle_1 = XString::operator char const*()
    UTF8Length(needle_1)
    
    if (strstr("aeiou", needle_1) == 0)
        return 1

return 0
