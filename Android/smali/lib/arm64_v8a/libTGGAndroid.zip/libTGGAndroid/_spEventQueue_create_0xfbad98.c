// 函数: _spEventQueue_create
// 地址: 0xfbad98
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t* result
int128_t v0
result, v0 = _spCalloc(1, 0x20, "..\..\ExternalCode\spine-c\src\spine\AnimationState.c", 0x45)
v0.q = 0x1000000000
*result = arg1
result[2] = 0x1000000000
result[1] = _spCalloc(0x10, 8, "..\..\ExternalCode\spine-c\src\spine\AnimationState.c", 0x49, v0)
result[3].d = 0
return result
