// 函数: _Z10Debt_Tokenv
// 地址: 0xa77a3c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t x0_2 = GetBoardPile(CardWhat(Trigger_BuyCard()), false)
return MoveTokens(zx.q(x0_2.d), 0x3f1, 0xc00, CountTokensWhereType(x0_2, 0xc00)) __tailcall
