// 函数: __stack_chk_fail
// 地址: 0x1111620
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

noreturn __stack_chk_fail() __tailcall
