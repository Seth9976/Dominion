// 函数: _Z10Amaas_Hintv
// 地址: 0xac4958
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return zx.q(CountWhereType(0x3e9, 4) s> 0 ? 1 : 0)
