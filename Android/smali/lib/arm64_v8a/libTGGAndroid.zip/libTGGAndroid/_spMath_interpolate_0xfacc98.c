// 函数: _spMath_interpolate
// 地址: 0xfacc98
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t v9
v9.d = arg3 f- arg2
return v9.d f* arg1(arg4) + arg2
