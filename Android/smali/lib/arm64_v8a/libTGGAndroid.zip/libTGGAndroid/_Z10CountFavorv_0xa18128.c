// 函数: _Z10CountFavorv
// 地址: 0xa18128
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x0 = DomGetContext()
return CountTokensPlayer(*(x0 + 8), zx.q(*(x0 + 0x18)), 0x1000) __tailcall
