// 函数: __cxa_get_globals
// 地址: 0x11215f0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return __cxa_get_globals() __tailcall
