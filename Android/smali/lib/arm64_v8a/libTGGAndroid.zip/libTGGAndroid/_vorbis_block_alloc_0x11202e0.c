// 函数: _vorbis_block_alloc
// 地址: 0x11202e0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _vorbis_block_alloc() __tailcall
