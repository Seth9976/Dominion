// 函数: _Z10AppendCardR11DomLogEvent11DomCardEnum
// 地址: 0x1110540
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return AppendCard(arg1, arg2) __tailcall
