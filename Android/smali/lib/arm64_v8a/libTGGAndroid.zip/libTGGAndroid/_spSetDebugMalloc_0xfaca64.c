// 函数: _spSetDebugMalloc
// 地址: 0xfaca64
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

data_2422580 = arg1
