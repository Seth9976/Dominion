// 函数: __cxa_increment_exception_refcount
// 地址: 0x10e9c1c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

SystemHintOp_BTI()

if (arg1 == 0)
    return 

int32_t i

do
    i = __stlxr(__ldaxr(arg1 - 0x78) + 1, arg1 - 0x78)
while (i != 0)
