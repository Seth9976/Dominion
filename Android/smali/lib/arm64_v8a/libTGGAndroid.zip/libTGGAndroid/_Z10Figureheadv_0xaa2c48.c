// 函数: _Z10Figureheadv
// 地址: 0xaa2c48
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

MoneyTreasure(3, 0)
int32_t var_c98 = 0
return StartOfNextTurn(sub_aae4e0, nullptr, &var_c98, 1, 2)
