// 函数: __cxa_throw
// 地址: 0x10e97c8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x0 = __cxa_get_globals()
*(arg1 - 0x60) = std::get_unexpected()
int64_t x0_2 = std::get_terminate()
*(arg1 - 0x70) = arg2
*(arg1 - 0x68) = arg3
*(arg1 - 0x58) = x0_2
sub_10e9848(arg1 - 0x20)
*(arg1 - 0x78) = 1
*(x0 + 8) += 1
*(arg1 - 0x18) = sub_10e9864
sub_1101c08(arg1 - 0x20)
sub_10e98d0(arg1 - 0x80)
noreturn
