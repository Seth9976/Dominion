// 函数: __cxa_bad_cast
// 地址: 0x10e9628
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x0 = __cxa_allocate_exception(8)
std::bad_cast::bad_cast()
__cxa_throw(x0, _typeinfo_for_std::bad_cast, std::bad_cast::~bad_cast)
noreturn
