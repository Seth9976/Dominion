// 函数: _Z10Delay_Hintv
// 地址: 0xa8b5d0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

CardsWhereType(0x3ea, 4)
int32_t var_18
return zx.q(var_18 == 0 ? 1 : 0)
