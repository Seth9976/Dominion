// 函数: _Z10CardCostFnRK10DomCardDef
// 地址: 0xbc5e68
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t x8_15 = *(arg1 + 0xe0)

if (x8_15 != 0)
    if (x8_15 == 3)
        return *(arg1 + 0 + 0xf8)
    
    int32_t x8_1 = *(arg1 + 0x1a0)
    
    if (x8_1 == 3)
        return *(arg1 + 0x1b8)
    
    if (x8_1 != 0)
        int32_t x8_2 = *(arg1 + 0x260)
        
        if (x8_2 != 0)
            if (x8_2 == 3)
                return *(arg1 + 2 * 0xc0 + 0xf8)
            
            int32_t x8_5 = *(arg1 + 0x320)
            
            if (x8_5 != 0)
                if (x8_5 == 3)
                    return *(arg1 + 0x338)
                
                int32_t x8_7 = *(arg1 + 0x3e0)
                
                if (x8_7 != 0)
                    if (x8_7 == 3)
                        return *(arg1 + 0x3f8)
                    
                    int32_t x8_9 = *(arg1 + 0x4a0)
                    
                    if (x8_9 != 0)
                        if (x8_9 == 3)
                            return *(arg1 + 0x4b8)
                        
                        int32_t x8_11 = *(arg1 + 0x560)
                        
                        if (x8_11 != 0)
                            if (x8_11 == 3)
                                return *(arg1 + 0x578)
                            
                            if (*(arg1 + 0x620) == 3)
                                return *(arg1 + 0x638)

return 0
