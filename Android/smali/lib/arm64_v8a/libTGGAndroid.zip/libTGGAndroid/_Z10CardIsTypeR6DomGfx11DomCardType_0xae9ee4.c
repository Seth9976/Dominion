// 函数: _Z10CardIsTypeR6DomGfx11DomCardType
// 地址: 0xae9ee4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return CardIs(gDomClient + 0x20728, zx.q(*(arg1 + 0x98)), arg2) __tailcall
