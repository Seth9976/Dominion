// 函数: _Z10FilterWhatR7CardIDs11DomCardEnum
// 地址: 0xad1508
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t var_78 = arg2
struct std::__ndk1::__function::__base<bool (CardID)>::std::__ndk1::__function::__func<FilterWhat(CardIDs&, DomCardEnum)::$_1, std::__ndk1::allocator<FilterWhat(CardIDs&, DomCardEnum)::$_1>, bool (CardID)>::VTable
    * const var_80 = &_vtable_for_std::__ndk1::__function::__func<FilterWhat(CardIDs&, DomCardEnum)::$_1, std::__ndk1::allocator<FilterWhat(CardIDs&, DomCardEnum)::$_1>, bool (CardID)>{for `std::__ndk1::__function::__base<bool (CardID)>'}
struct std::__ndk1::__function::__base<bool (CardID)>::std::__ndk1::__function::__func<FilterWhat(CardIDs&, DomCardEnum)::$_1, std::__ndk1::allocator<FilterWhat(CardIDs&, DomCardEnum)::$_1>, bool (CardID)>::VTable
    * const* result = &var_80
struct std::__ndk1::__function::__base<bool (CardID)>::std::__ndk1::__function::__func<FilterWhat(CardIDs&, DomCardEnum)::$_1, std::__ndk1::allocator<FilterWhat(CardIDs&, DomCardEnum)::$_1>, bool (CardID)>::VTable
    * const var_50
int64_t* var_30 = &var_50
var_50 = &_vtable_for_std::__ndk1::__function::__func<FilterWhat(CardIDs&, DomCardEnum)::$_1, std::__ndk1::allocator<FilterWhat(CardIDs&, DomCardEnum)::$_1>, bool (CardID)>{for `std::__ndk1::__function::__base<bool (CardID)>'}
int32_t var_48 = arg2
int32_t var_14
*(arg1 + 0xc80) = FilterCardsInt(&var_50, arg1, *(arg1 + 0xc80), nullptr, &var_14)

if (&var_50 == var_30)
    (*(*var_30 + 0x20))()
else if (var_30 != 0)
    (*(*var_30 + 0x28))()

int64_t (* const x8_5)(void* arg1)

if (&var_80 == result)
    x8_5 = (*result)->vFunc_4
else
    if (result == 0)
        return result
    
    x8_5 = (*result)->j_operator delete

return x8_5()
