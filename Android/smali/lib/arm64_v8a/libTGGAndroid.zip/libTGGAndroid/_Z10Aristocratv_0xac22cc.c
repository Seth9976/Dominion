// 函数: _Z10Aristocratv
// 地址: 0xac22cc
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t result = CountWhereWhat(0x3e9, 0x1205, 0xffffffff)
uint64_t x8 = zx.q(result.d - 1)

if (x8.d u> 7)
    return result

switch (x8)
    case 0, 4
        return Action(3, 0) __tailcall
    case 1, 5
        return Card(3, 0, 0, nullptr) __tailcall
    case 2, 6
        return MoneyPlus(3, 0, false) __tailcall
    case 3, 7
        return Buy(3, 0) __tailcall
