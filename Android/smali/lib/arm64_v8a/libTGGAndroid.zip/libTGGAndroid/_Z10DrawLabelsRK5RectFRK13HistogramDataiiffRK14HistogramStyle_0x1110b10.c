// 函数: _Z10DrawLabelsRK5RectFRK13HistogramDataiiffRK14HistogramStyle
// 地址: 0x1110b10
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return DrawLabels(arg1, arg2, arg3, arg4, arg6, arg7, arg5) __tailcall
