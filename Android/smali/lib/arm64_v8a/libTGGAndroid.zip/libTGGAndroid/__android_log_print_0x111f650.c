// 函数: __android_log_print
// 地址: 0x111f650
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return __android_log_print() __tailcall
