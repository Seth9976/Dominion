// 函数: _Z10ChooseCardRK7CardIDs14ActiveSetStyleRK11DomChoiceUI15DomChoiceAIHint14DomChoiceFlags
// 地址: 0x11097e0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return ChooseCard(arg1, arg2, arg3, arg4, arg5) __tailcall
