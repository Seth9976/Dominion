// 函数: _spDeformTimeline_getPropertyId
// 地址: 0xfb0ecc
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return zx.q(*(*(arg1 + 0x40) + 0x58) + *(arg1 + 0x38) + 0x30000000)
