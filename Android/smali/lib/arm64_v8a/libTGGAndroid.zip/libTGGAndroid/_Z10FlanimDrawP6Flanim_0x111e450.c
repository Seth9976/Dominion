// 函数: _Z10FlanimDrawP6Flanim
// 地址: 0x111e450
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return FlanimDraw(arg1) __tailcall
