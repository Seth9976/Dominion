// 函数: __register_atfork
// 地址: 0x1106580
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return __register_atfork(prepare, parent, child, dso_handle) __tailcall
