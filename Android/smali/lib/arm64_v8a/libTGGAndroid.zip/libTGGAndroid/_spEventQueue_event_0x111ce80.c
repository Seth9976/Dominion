// 函数: _spEventQueue_event
// 地址: 0x111ce80
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _spEventQueue_event() __tailcall
