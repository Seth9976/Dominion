// 函数: __cxa_rethrow_primary_exception
// 地址: 0x11207b0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return __cxa_rethrow_primary_exception() __tailcall
