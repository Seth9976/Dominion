// 函数: _Z10BidingTimev
// 地址: 0xac3414
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int32_t var_c98 = 0
return Forever(0, BidingTime_InCleanup, BidingTime_Test, 0x10000, &var_c98, 0x51)
