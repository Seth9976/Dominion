// 函数: _spMath_random
// 地址: 0xfacb58
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t v9
v9.d = arg2 f- arg1
return v9.d f* data_11bbe28() + arg1
