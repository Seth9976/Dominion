// 函数: _Z10Chancellorv
// 地址: 0xa264a4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

MoneyPlus(2, 0, false)
struct std::__ndk1::__function::__base<void ()>::std::__ndk1::__function::__func<Chancellor()::$_5, std::__ndk1::allocator<Chancellor()::$_5>, void ()>::VTable
    * const var_40 = &_vtable_for_std::__ndk1::__function::__func<Chancellor()::$_5, std::__ndk1::allocator<Chancellor()::$_5>, void ()>{for `std::__ndk1::__function::__base<void ()>'}
struct std::__ndk1::__function::__base<void ()>::std::__ndk1::__function::__func<Chancellor()::$_5, std::__ndk1::allocator<Chancellor()::$_5>, void ()>::VTable
    * const* result = &var_40
int128_t var_80
__builtin_memset(&var_80, 0, 0x38)
May(&var_40, 0x5d, &var_80)
int64_t (* const x8_2)(void* arg1)

if (&var_40 == result)
    x8_2 = (*result)->vFunc_4
else
    if (result == 0)
        return result
    
    x8_2 = (*result)->j_operator delete

return x8_2()
