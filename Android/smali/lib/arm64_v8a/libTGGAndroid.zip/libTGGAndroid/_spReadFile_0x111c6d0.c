// 函数: _spReadFile
// 地址: 0x111c6d0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _spReadFile() __tailcall
