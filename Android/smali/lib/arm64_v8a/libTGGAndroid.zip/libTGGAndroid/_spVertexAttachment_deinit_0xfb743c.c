// 函数: _spVertexAttachment_deinit
// 地址: 0xfb743c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

_spAttachment_deinit()
_spFree(*(arg1 + 0x30))
return _spFree(*(arg1 + 0x40)) __tailcall
