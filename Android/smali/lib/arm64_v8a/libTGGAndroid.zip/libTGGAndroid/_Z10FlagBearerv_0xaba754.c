// 函数: _Z10FlagBearerv
// 地址: 0xaba754
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return MoneyPlus(2, 0, false) __tailcall
