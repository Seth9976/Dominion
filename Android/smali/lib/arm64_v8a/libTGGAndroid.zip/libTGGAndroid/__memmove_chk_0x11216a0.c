// 函数: __memmove_chk
// 地址: 0x11216a0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return __memmove_chk(dest, src, len, destlen) __tailcall
