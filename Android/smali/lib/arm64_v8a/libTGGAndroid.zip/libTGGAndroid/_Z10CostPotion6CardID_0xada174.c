// 函数: _Z10CostPotion6CardID
// 地址: 0xada174
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x0 = DomGetContext()
CardCostParse(zx.q(CardCost(*(x0 + 8), zx.q(*(x0 + 0x18)), zx.q(arg1), 0)))
int32_t var_24
return zx.q(var_24 s> 0 ? 1 : 0)
