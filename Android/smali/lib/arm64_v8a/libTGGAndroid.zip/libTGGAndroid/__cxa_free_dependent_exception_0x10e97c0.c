// 函数: __cxa_free_dependent_exception
// 地址: 0x10e97c0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

SystemHintOp_BTI()
return sub_10ff5c0(arg1) __tailcall
