// 函数: _Z10FabDispose5FabID
// 地址: 0xf6235c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x9_1 = *gFabs + mulu.dp.d(arg1.d & 0xffff, 0x4e8)
int32_t x11 = *(gFabs + 0x10)
*(gFabs + 0x10) = zx.d(*(x9_1 + 0x4e0))
*(x9_1 + 0x4e0) = x11
*(gFabs + 0x14) -= 1
