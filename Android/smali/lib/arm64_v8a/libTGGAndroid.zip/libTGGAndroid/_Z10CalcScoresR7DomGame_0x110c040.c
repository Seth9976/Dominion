// 函数: _Z10CalcScoresR7DomGame
// 地址: 0x110c040
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return CalcScores(arg1) __tailcall
