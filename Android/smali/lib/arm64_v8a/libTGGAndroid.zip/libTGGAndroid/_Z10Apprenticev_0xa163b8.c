// 函数: _Z10Apprenticev
// 地址: 0xa163b8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

Action(1, 0)
int64_t result = TrashOne(7, 0)

if (result.d != 0)
    Card(CostOnlyCoin(result), 0, 0, nullptr)
    result = CostPotion(zx.q(result.d))
    
    if ((result.d & 1) != 0)
        return Card(2, 0, 0, nullptr) __tailcall

return result
