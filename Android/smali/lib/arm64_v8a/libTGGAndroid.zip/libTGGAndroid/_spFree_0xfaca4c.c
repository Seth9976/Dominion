// 函数: _spFree
// 地址: 0xfaca4c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return data_11bbe20() __tailcall
