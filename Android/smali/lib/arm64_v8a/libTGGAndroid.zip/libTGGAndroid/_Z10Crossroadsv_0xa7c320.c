// 函数: _Z10Crossroadsv
// 地址: 0xa7c320
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

RevealHandTemp()
Card(CountWhereType(0x3ea, 8), 0, 0, nullptr)
int64_t result = FirstTimePlayingCard(0x800)

if ((result.d & 1) == 0)
    return result

Action(3, 0)
return NotifyResult(1) __tailcall
