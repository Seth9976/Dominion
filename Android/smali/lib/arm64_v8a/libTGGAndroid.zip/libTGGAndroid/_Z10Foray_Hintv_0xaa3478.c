// 函数: _Z10Foray_Hintv
// 地址: 0xaa3478
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

CardsHand()
void var_c98
FilterUnique(&var_c98, nullptr)
int32_t var_18
return zx.q(var_18 s> 2 ? 1 : 0)
