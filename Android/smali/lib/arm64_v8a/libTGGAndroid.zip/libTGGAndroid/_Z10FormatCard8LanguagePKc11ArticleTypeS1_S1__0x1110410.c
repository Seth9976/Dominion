// 函数: _Z10FormatCard8LanguagePKc11ArticleTypeS1_S1_
// 地址: 0x1110410
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return FormatCard(arg1, arg2, arg3, arg4, arg5) __tailcall
