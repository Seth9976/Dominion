// 函数: _Z10CircleDraw4Vec2f10ColorRgbaIP6XAsset
// 地址: 0x11109e0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return CircleDraw(arg1, arg4, arg2, arg3) __tailcall
