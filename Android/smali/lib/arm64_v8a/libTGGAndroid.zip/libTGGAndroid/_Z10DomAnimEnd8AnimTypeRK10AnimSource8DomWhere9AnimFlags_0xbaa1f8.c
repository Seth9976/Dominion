// 函数: _Z10DomAnimEnd8AnimTypeRK10AnimSource8DomWhere9AnimFlags
// 地址: 0xbaa1f8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

if (arg3 == 0 || (arg4 & 0x100) != 0)
    return 

if (arg1.d u> 8)
    pthread_kill(pthread_self(), 6)
    return DomAnimSource(XNoReturn()) __tailcall

if ((1 << arg1.d & 0x1ee) != 0)
    return 

if (arg1.d != 4)
    pthread_kill(pthread_self(), 6)
    return DomAnimSource(XNoReturn()) __tailcall

if ((arg4 & 8) != 0)
    return DomSoundCardReaction(zx.q(*(arg2 + 8)), zx.q(*(arg2 + 0xc))) __tailcall
