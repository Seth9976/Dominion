// 函数: _Z10CountMoneyv
// 地址: 0xad1d34
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x0 = DomGetContext()
return CountResource(*(x0 + 8), zx.q(*(x0 + 0x18)), 0) __tailcall
