// 函数: _spClippingAttachment_dispose
// 地址: 0xfc887c
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

_spVertexAttachment_deinit()
return _spFree(arg1) __tailcall
