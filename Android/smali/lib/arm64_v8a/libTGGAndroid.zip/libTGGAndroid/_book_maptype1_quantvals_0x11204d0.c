// 函数: _book_maptype1_quantvals
// 地址: 0x11204d0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _book_maptype1_quantvals() __tailcall
