// 函数: _Z10BinGetHeadRK5Bin2DRK5Vec2I
// 地址: 0xc10ea4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return *(*(arg1 + 0x18) + (sx.q(*arg2 + *(arg1 + 0x40) * *(arg2 + 4)) << 3))
