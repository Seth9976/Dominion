// 函数: _Z10FabHitTest5FabIDRK3Ray
// 地址: 0xf61838
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return FabHitTest(*gFabs + mulu.dp.d(zx.d(arg1), 0x4e8), arg2) __tailcall
