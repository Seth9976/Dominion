// 函数: _Z10AddOngoing14DomOngoingTypei18DomAbilityDurationb11OngoingFlag12DomTokenIcon11DomCardEnumi
// 地址: 0x1109b80
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return AddOngoing(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) __tailcall
