// 函数: _Z10Draw3DInitv
// 地址: 0xc9a1f8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t result
int128_t v0
int128_t v1
int128_t v2
int128_t v3
int128_t v4
int128_t v5
int128_t v6
result, v0, v1, v2, v3, v4, v5, v6 = memset(gDraw3DData, 0, "c}")
v0 = *M4I
v1 = *(M4I + 0x10)
v3 = *(M4I + 0x20)
v5 = *(M4I + 0x30)
v2 = *M4I
v4 = *(M4I + 0x10)
*(gDraw3DData + 0x2d4) = v0
*(gDraw3DData + 0x2e4) = v1
*(gDraw3DData + 0x2f4) = v3
*(gDraw3DData + 0x304) = v5
*(gDraw3DData + 0x188) = v0
*(gDraw3DData + 0x198) = v1
*(gDraw3DData + 0x1a8) = v3
*(gDraw3DData + 0x1b8) = v5
*(gDraw3DData + 0x208) = v0
v6 = *(M4I + 0x20)
v0 = *(M4I + 0x30)
*(gDraw3DData + 0x218) = v1
*(gDraw3DData + 0x228) = v3
*(gDraw3DData + 0x238) = v5
*(gDraw3DData + 0x1f8) = v0
v0 = *(M4I + 0x10)
*(gDraw3DData + 0x1e8) = *(M4I + 0x20)
v1 = *M4I
*(gDraw3DData + 0x1d8) = v0
v0 = *(M4I + 0x30)
*(gDraw3DData + 0x1c8) = v1
*(gDraw3DData + 0x178) = v0
*(gDraw3DData + 0x168) = v6
v0 = *gRgbaWhite
*(gDraw3DData + 0x158) = v4
uint32_t x9_1 = *gRgbaIGreen
*(gDraw3DData + 0x148) = v2
*(gDraw3DData + 0x38) = x9_1
*(gDraw3DData + 0x410) = v0
*(gDraw3DData + &data_7a4604) = 5
return result
