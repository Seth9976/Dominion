// 函数: __cxa_allocate_dependent_exception
// 地址: 0x10e9784
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* result = sub_10ff3f4(0x80)

if (result == 0)
    std::terminate()
    noreturn

__builtin_memset(result, 0, 0x80)
return result
