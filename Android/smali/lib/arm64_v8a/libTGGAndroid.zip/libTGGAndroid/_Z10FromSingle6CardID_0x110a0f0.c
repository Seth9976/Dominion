// 函数: _Z10FromSingle6CardID
// 地址: 0x110a0f0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return FromSingle(arg1) __tailcall
