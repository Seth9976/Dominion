// 函数: _Z10EvalValGetI4Vec4ET_12UI2StateTypeRK7EvalVal
// 地址: 0x100eed4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int128_t v0
v0.d = *(arg2 + 8)
int128_t v1
v1.d = *(arg2 + 0xc)
int128_t v2
v2.d = *(arg2 + 0x10)
int128_t v3
v3.d = *(arg2 + 0x14)
return arg1
