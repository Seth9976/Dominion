// 函数: _ve_envelope_clear
// 地址: 0x1086b90
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

mdct_clear(arg1 + 0x10)
free(*(arg1 + 0x40))
free(*(arg1 + 0x58))
free(*(arg1 + 0x70))
free(*(arg1 + 0x88))
free(*(arg1 + 0xa0))
free(*(arg1 + 0xb8))
free(*(arg1 + 0xd0))
free(*(arg1 + 0x30))
free(*(arg1 + 0xe0))
free(*(arg1 + 0xf0))
return memset(arg1, 0, 0x118) __tailcall
