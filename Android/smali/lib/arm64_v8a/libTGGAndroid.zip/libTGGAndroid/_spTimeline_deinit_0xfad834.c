// 函数: _spTimeline_deinit
// 地址: 0xfad834
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return _spFree(*(arg1 + 8)) __tailcall
