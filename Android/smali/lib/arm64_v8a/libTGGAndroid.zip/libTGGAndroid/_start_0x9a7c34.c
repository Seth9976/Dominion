// 函数: _start
// 地址: 0x9a7c34
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

SystemHintOp_BTI()
return __cxa_finalize(&data_1122730) __tailcall
