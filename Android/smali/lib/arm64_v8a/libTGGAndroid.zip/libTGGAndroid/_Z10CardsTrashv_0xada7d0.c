// 函数: _Z10CardsTrashv
// 地址: 0xada7d0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return CardsWhereType(2, 0, 0) __tailcall
