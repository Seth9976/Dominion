// 函数: __cxa_throw_bad_array_new_length
// 地址: 0x10e9698
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

void* x0 = __cxa_allocate_exception(8)
std::bad_array_new_length::bad_array_new_length()
__cxa_throw(x0, _typeinfo_for_std::bad_array_new_length, 
    std::bad_array_new_length::~bad_array_new_length)
noreturn
