// 函数: __cxa_pure_virtual
// 地址: 0x10ff3c4
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

sub_10ea1a4("Pure virtual function called!", arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
noreturn
