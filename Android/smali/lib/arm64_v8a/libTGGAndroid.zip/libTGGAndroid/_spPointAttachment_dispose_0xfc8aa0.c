// 函数: _spPointAttachment_dispose
// 地址: 0xfc8aa0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

_spAttachment_deinit()
return _spFree(arg1) __tailcall
