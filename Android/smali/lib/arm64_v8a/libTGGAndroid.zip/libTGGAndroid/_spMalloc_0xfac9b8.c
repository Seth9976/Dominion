// 函数: _spMalloc
// 地址: 0xfac9b8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

int64_t x3 = data_2422580

if (x3 == 0)
    return data_11bbe10() __tailcall

return x3() __tailcall
