// 函数: _Z10EquiToCubeP6XAsset
// 地址: 0xf723c8
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

AssetNameFromPath(XString::operator char const*())
XString::XString()
XString::XString()
XString var_28
void var_20
AssetNameSplit(XString::operator char const*(), &var_20, &var_28)
XAsset* var_58
DrawCubemap(arg1, &var_58, 0x400, 1)
char var_78
XString::XString(&var_78)
XString::operator+(&var_20)
void var_70
XString::operator+(&var_70)
char var_80
XString::XString(&var_80)
void var_68
XString::operator+(&var_68)
XString::~XString()
XString::~XString()
XString::~XString()
XString::~XString()
void var_88
XString::XString(&var_88)
PNGCubemapExport(0x400, &var_58, &var_88)
XString::~XString()
XString::~XString()
XString::~XString()
XString::~XString()
return XString::~XString()
