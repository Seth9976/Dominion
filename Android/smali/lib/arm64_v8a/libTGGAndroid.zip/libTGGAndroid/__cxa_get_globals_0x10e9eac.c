// 函数: __cxa_get_globals
// 地址: 0x10e9eac
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

return __emutls_get_address(0x11c1a88)
