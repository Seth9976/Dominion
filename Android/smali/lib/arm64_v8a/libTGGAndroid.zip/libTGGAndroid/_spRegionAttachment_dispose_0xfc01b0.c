// 函数: _spRegionAttachment_dispose
// 地址: 0xfc01b0
// 来自: E:\torrent\Cursor\Dominion_1.0.3315\split_config.arm64_v8a\lib\arm64-v8a\libTGGAndroid.so

_spAttachment_deinit()
_spFree(*(arg1 + 0x28))
return _spFree(arg1) __tailcall
