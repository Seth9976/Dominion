package android.view;

public interface WindowInsetsAnimationControlListener {
    static {
        throw new NoClassDefFoundError();
    }
}

