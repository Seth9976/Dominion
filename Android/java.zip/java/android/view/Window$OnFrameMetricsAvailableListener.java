package android.view;

public interface Window.OnFrameMetricsAvailableListener {
    static {
        throw new NoClassDefFoundError();
    }
}

