package android.location;

public class GnssStatus.Callback {
    static {
        throw new NoClassDefFoundError();
    }
}

