package androidx.activity;

public final class R {
    public static final class attr {
        public static int alpha = 0x7F010000;  // attr:alpha
        public static int font = 0x7F010004;  // attr:font
        public static int fontProviderAuthority = 0x7F010005;  // attr:fontProviderAuthority
        public static int fontProviderCerts = 0x7F010006;  // attr:fontProviderCerts
        public static int fontProviderFetchStrategy = 0x7F010007;  // attr:fontProviderFetchStrategy
        public static int fontProviderFetchTimeout = 0x7F010008;  // attr:fontProviderFetchTimeout
        public static int fontProviderPackage = 0x7F010009;  // attr:fontProviderPackage
        public static int fontProviderQuery = 0x7F01000A;  // attr:fontProviderQuery
        public static int fontStyle = 0x7F01000C;  // attr:fontStyle
        public static int fontVariationSettings = 0x7F01000D;  // attr:fontVariationSettings
        public static int fontWeight = 0x7F01000E;  // attr:fontWeight
        public static int ttcIndex = 0x7F010016;  // attr:ttcIndex

    }

    public static final class color {
        public static int notification_action_color_filter = 0x7F02000D;  // color:notification_action_color_filter
        public static int notification_icon_bg_color = 0x7F02000E;  // color:notification_icon_bg_color

    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7F030000;  // dimen:compat_button_inset_horizontal_material
        public static int compat_button_inset_vertical_material = 0x7F030001;  // dimen:compat_button_inset_vertical_material
        public static int compat_button_padding_horizontal_material = 0x7F030002;  // dimen:compat_button_padding_horizontal_material
        public static int compat_button_padding_vertical_material = 0x7F030003;  // dimen:compat_button_padding_vertical_material
        public static int compat_control_corner_material = 0x7F030004;  // dimen:compat_control_corner_material
        public static int compat_notification_large_icon_max_height = 0x7F030005;  // dimen:compat_notification_large_icon_max_height
        public static int compat_notification_large_icon_max_width = 0x7F030006;  // dimen:compat_notification_large_icon_max_width
        public static int notification_action_icon_size = 0x7F030007;  // dimen:notification_action_icon_size
        public static int notification_action_text_size = 0x7F030008;  // dimen:notification_action_text_size
        public static int notification_big_circle_margin = 0x7F030009;  // dimen:notification_big_circle_margin
        public static int notification_content_margin_start = 0x7F03000A;  // dimen:notification_content_margin_start
        public static int notification_large_icon_height = 0x7F03000B;  // dimen:notification_large_icon_height
        public static int notification_large_icon_width = 0x7F03000C;  // dimen:notification_large_icon_width
        public static int notification_main_column_padding_top = 0x7F03000D;  // dimen:notification_main_column_padding_top
        public static int notification_media_narrow_margin = 0x7F03000E;  // dimen:notification_media_narrow_margin
        public static int notification_right_icon_size = 0x7F03000F;  // dimen:notification_right_icon_size
        public static int notification_right_side_padding_top = 0x7F030010;  // dimen:notification_right_side_padding_top
        public static int notification_small_icon_background_padding = 0x7F030011;  // dimen:notification_small_icon_background_padding
        public static int notification_small_icon_size_as_large = 0x7F030012;  // dimen:notification_small_icon_size_as_large
        public static int notification_subtext_size = 0x7F030013;  // dimen:notification_subtext_size
        public static int notification_top_pad = 0x7F030014;  // dimen:notification_top_pad
        public static int notification_top_pad_large_text = 0x7F030015;  // dimen:notification_top_pad_large_text

    }

    public static final class drawable {
        public static int notification_action_background = 0x7F040018;  // drawable:notification_action_background
        public static int notification_bg = 0x7F040019;  // drawable:notification_bg
        public static int notification_bg_low = 0x7F04001A;  // drawable:notification_bg_low
        public static int notification_bg_low_normal = 0x7F04001B;
        public static int notification_bg_low_pressed = 0x7F04001C;
        public static int notification_bg_normal = 0x7F04001D;
        public static int notification_bg_normal_pressed = 0x7F04001E;
        public static int notification_icon_background = 0x7F04001F;  // drawable:notification_icon_background
        public static int notification_template_icon_bg = 0x7F040020;  // drawable:notification_template_icon_bg
        public static int notification_template_icon_low_bg = 0x7F040021;  // drawable:notification_template_icon_low_bg
        public static int notification_tile_bg = 0x7F040022;  // drawable:notification_tile_bg
        public static int notify_panel_notification_icon_bg = 0x7F040023;

    }

    public static final class id {
        public static int accessibility_action_clickable_span = 0x7F050000;  // id:accessibility_action_clickable_span
        public static int accessibility_custom_action_0 = 0x7F050001;  // id:accessibility_custom_action_0
        public static int accessibility_custom_action_1 = 0x7F050002;  // id:accessibility_custom_action_1
        public static int accessibility_custom_action_10 = 0x7F050003;  // id:accessibility_custom_action_10
        public static int accessibility_custom_action_11 = 0x7F050004;  // id:accessibility_custom_action_11
        public static int accessibility_custom_action_12 = 0x7F050005;  // id:accessibility_custom_action_12
        public static int accessibility_custom_action_13 = 0x7F050006;  // id:accessibility_custom_action_13
        public static int accessibility_custom_action_14 = 0x7F050007;  // id:accessibility_custom_action_14
        public static int accessibility_custom_action_15 = 0x7F050008;  // id:accessibility_custom_action_15
        public static int accessibility_custom_action_16 = 0x7F050009;  // id:accessibility_custom_action_16
        public static int accessibility_custom_action_17 = 0x7F05000A;  // id:accessibility_custom_action_17
        public static int accessibility_custom_action_18 = 0x7F05000B;  // id:accessibility_custom_action_18
        public static int accessibility_custom_action_19 = 0x7F05000C;  // id:accessibility_custom_action_19
        public static int accessibility_custom_action_2 = 0x7F05000D;  // id:accessibility_custom_action_2
        public static int accessibility_custom_action_20 = 0x7F05000E;  // id:accessibility_custom_action_20
        public static int accessibility_custom_action_21 = 0x7F05000F;  // id:accessibility_custom_action_21
        public static int accessibility_custom_action_22 = 0x7F050010;  // id:accessibility_custom_action_22
        public static int accessibility_custom_action_23 = 0x7F050011;  // id:accessibility_custom_action_23
        public static int accessibility_custom_action_24 = 0x7F050012;  // id:accessibility_custom_action_24
        public static int accessibility_custom_action_25 = 0x7F050013;  // id:accessibility_custom_action_25
        public static int accessibility_custom_action_26 = 0x7F050014;  // id:accessibility_custom_action_26
        public static int accessibility_custom_action_27 = 0x7F050015;  // id:accessibility_custom_action_27
        public static int accessibility_custom_action_28 = 0x7F050016;  // id:accessibility_custom_action_28
        public static int accessibility_custom_action_29 = 0x7F050017;  // id:accessibility_custom_action_29
        public static int accessibility_custom_action_3 = 0x7F050018;  // id:accessibility_custom_action_3
        public static int accessibility_custom_action_30 = 0x7F050019;  // id:accessibility_custom_action_30
        public static int accessibility_custom_action_31 = 0x7F05001A;  // id:accessibility_custom_action_31
        public static int accessibility_custom_action_4 = 0x7F05001B;  // id:accessibility_custom_action_4
        public static int accessibility_custom_action_5 = 0x7F05001C;  // id:accessibility_custom_action_5
        public static int accessibility_custom_action_6 = 0x7F05001D;  // id:accessibility_custom_action_6
        public static int accessibility_custom_action_7 = 0x7F05001E;  // id:accessibility_custom_action_7
        public static int accessibility_custom_action_8 = 0x7F05001F;  // id:accessibility_custom_action_8
        public static int accessibility_custom_action_9 = 0x7F050020;  // id:accessibility_custom_action_9
        public static int action_container = 0x7F050021;  // id:action_container
        public static int action_divider = 0x7F050022;  // id:action_divider
        public static int action_image = 0x7F050023;  // id:action_image
        public static int action_text = 0x7F050024;  // id:action_text
        public static int actions = 0x7F050025;  // id:actions
        public static int async = 0x7F050028;  // id:async
        public static int blocking = 0x7F05002A;  // id:blocking
        public static int chronometer = 0x7F05002B;  // id:chronometer
        public static int dialog_button = 0x7F05002D;  // id:dialog_button
        public static int forever = 0x7F05002E;  // id:forever
        public static int icon = 0x7F05002F;  // id:icon
        public static int icon_group = 0x7F050030;  // id:icon_group
        public static int info = 0x7F050032;  // id:info
        public static int italic = 0x7F050033;  // id:italic
        public static int line1 = 0x7F050035;  // id:line1
        public static int line3 = 0x7F050036;  // id:line3
        public static int normal = 0x7F050038;  // id:normal
        public static int notification_background = 0x7F050039;  // id:notification_background
        public static int notification_main_column = 0x7F05003A;  // id:notification_main_column
        public static int notification_main_column_container = 0x7F05003B;  // id:notification_main_column_container
        public static int right_icon = 0x7F05003C;  // id:right_icon
        public static int right_side = 0x7F05003D;  // id:right_side
        public static int tag_accessibility_actions = 0x7F05003F;  // id:tag_accessibility_actions
        public static int tag_accessibility_clickable_spans = 0x7F050040;  // id:tag_accessibility_clickable_spans
        public static int tag_accessibility_heading = 0x7F050041;  // id:tag_accessibility_heading
        public static int tag_accessibility_pane_title = 0x7F050042;  // id:tag_accessibility_pane_title
        public static int tag_screen_reader_focusable = 0x7F050046;  // id:tag_screen_reader_focusable
        public static int tag_transition_group = 0x7F050048;  // id:tag_transition_group
        public static int tag_unhandled_key_event_manager = 0x7F050049;  // id:tag_unhandled_key_event_manager
        public static int tag_unhandled_key_listeners = 0x7F05004A;  // id:tag_unhandled_key_listeners
        public static int text = 0x7F05004C;  // id:text
        public static int text2 = 0x7F05004D;  // id:text2
        public static int time = 0x7F05004E;  // id:time
        public static int title = 0x7F05004F;  // id:title
        public static int view_tree_lifecycle_owner = 0x7F050050;  // id:view_tree_lifecycle_owner
        public static int view_tree_saved_state_registry_owner = 0x7F050051;  // id:view_tree_saved_state_registry_owner
        public static int view_tree_view_model_store_owner = 0x7F050052;  // id:view_tree_view_model_store_owner

    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7F060001;  // integer:status_bar_notification_info_maxnum

    }

    public static final class layout {
        public static int custom_dialog = 0x7F070000;  // layout:custom_dialog
        public static int notification_action = 0x7F070001;  // layout:notification_action
        public static int notification_action_tombstone = 0x7F070002;  // layout:notification_action_tombstone
        public static int notification_template_custom_big = 0x7F070003;  // layout:notification_template_custom_big
        public static int notification_template_icon_group = 0x7F070004;  // layout:notification_template_icon_group
        public static int notification_template_part_chronometer = 0x7F070005;  // layout:notification_template_part_chronometer
        public static int notification_template_part_time = 0x7F070006;  // layout:notification_template_part_time

    }

    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7F0A001C;  // string:status_bar_notification_info_overflow "999+"

    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7F0B0000;  // style:TextAppearance.Compat.Notification
        public static int TextAppearance_Compat_Notification_Info = 0x7F0B0001;  // style:TextAppearance.Compat.Notification.Info
        public static int TextAppearance_Compat_Notification_Line2 = 0x7F0B0002;  // style:TextAppearance.Compat.Notification.Line2
        public static int TextAppearance_Compat_Notification_Time = 0x7F0B0003;  // style:TextAppearance.Compat.Notification.Time
        public static int TextAppearance_Compat_Notification_Title = 0x7F0B0004;  // style:TextAppearance.Compat.Notification.Title
        public static int Widget_Compat_NotificationActionContainer = 0x7F0B0006;  // style:Widget.Compat.NotificationActionContainer
        public static int Widget_Compat_NotificationActionText = 0x7F0B0007;  // style:Widget.Compat.NotificationActionText

    }

    public static final class styleable {
        public static int[] ColorStateListItem = null;
        public static int ColorStateListItem_alpha = 3;
        public static int ColorStateListItem_android_alpha = 1;
        public static int ColorStateListItem_android_color = 0;
        public static int ColorStateListItem_android_lStar = 2;
        public static int ColorStateListItem_lStar = 4;
        public static int[] FontFamily = null;
        public static int[] FontFamilyFont = null;
        public static int FontFamilyFont_android_font = 0;
        public static int FontFamilyFont_android_fontStyle = 2;
        public static int FontFamilyFont_android_fontVariationSettings = 4;
        public static int FontFamilyFont_android_fontWeight = 1;
        public static int FontFamilyFont_android_ttcIndex = 3;
        public static int FontFamilyFont_font = 5;
        public static int FontFamilyFont_fontStyle = 6;
        public static int FontFamilyFont_fontVariationSettings = 7;
        public static int FontFamilyFont_fontWeight = 8;
        public static int FontFamilyFont_ttcIndex = 9;
        public static int FontFamily_fontProviderAuthority = 0;
        public static int FontFamily_fontProviderCerts = 1;
        public static int FontFamily_fontProviderFetchStrategy = 2;
        public static int FontFamily_fontProviderFetchTimeout = 3;
        public static int FontFamily_fontProviderPackage = 4;
        public static int FontFamily_fontProviderQuery = 5;
        public static int FontFamily_fontProviderSystemFontFamily = 6;
        public static int[] GradientColor = null;
        public static int[] GradientColorItem = null;
        public static int GradientColorItem_android_color = 0;
        public static int GradientColorItem_android_offset = 1;
        public static int GradientColor_android_centerColor = 7;
        public static int GradientColor_android_centerX = 3;
        public static int GradientColor_android_centerY = 4;
        public static int GradientColor_android_endColor = 1;
        public static int GradientColor_android_endX = 10;
        public static int GradientColor_android_endY = 11;
        public static int GradientColor_android_gradientRadius = 5;
        public static int GradientColor_android_startColor = 0;
        public static int GradientColor_android_startX = 8;
        public static int GradientColor_android_startY = 9;
        public static int GradientColor_android_tileMode = 6;
        public static int GradientColor_android_type = 2;

        static {
            styleable.ColorStateListItem = new int[]{0x10101A5, 0x101031F, 0x1010647, 0x7F010000, 0x7F010011};  // attr:alpha
            styleable.FontFamily = new int[]{0x7F010005, 0x7F010006, 0x7F010007, 0x7F010008, 0x7F010009, 0x7F01000A, 0x7F01000B};  // attr:fontProviderAuthority
            styleable.FontFamilyFont = new int[]{0x1010532, 0x1010533, 0x101053F, 0x101056F, 0x1010570, 0x7F010004, 0x7F01000C, 0x7F01000D, 0x7F01000E, 0x7F010016};  // attr:font
            styleable.GradientColor = new int[]{0x101019D, 0x101019E, 0x10101A1, 0x10101A2, 0x10101A3, 0x10101A4, 0x1010201, 0x101020B, 0x1010510, 0x1010511, 0x1010512, 0x1010513};
            styleable.GradientColorItem = new int[]{0x10101A5, 0x1010514};
        }
    }

}

