package androidx.core.content.res;

import android.graphics.Typeface;

public final class ResourcesCompat.FontCallback..ExternalSyntheticLambda0 implements Runnable {
    public final FontCallback f$0;
    public final Typeface f$1;

    public ResourcesCompat.FontCallback..ExternalSyntheticLambda0(FontCallback resourcesCompat$FontCallback0, Typeface typeface0) {
        this.f$0 = resourcesCompat$FontCallback0;
        this.f$1 = typeface0;
    }

    @Override
    public final void run() {
        this.f$0.lambda$callbackSuccessAsync$0$androidx-core-content-res-ResourcesCompat$FontCallback(this.f$1);
    }
}

