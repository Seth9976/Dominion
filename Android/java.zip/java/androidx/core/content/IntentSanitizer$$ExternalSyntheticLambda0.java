package androidx.core.content;

import androidx.core.util.Consumer;

public final class IntentSanitizer..ExternalSyntheticLambda0 implements Consumer {
    @Override  // androidx.core.util.Consumer
    public final void accept(Object object0) {
        IntentSanitizer.lambda$sanitizeByThrowing$1(((String)object0));
    }
}

