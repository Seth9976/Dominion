package androidx.core.content;

import androidx.core.util.Consumer;

public final class IntentSanitizer..ExternalSyntheticLambda1 implements Consumer {
    @Override  // androidx.core.util.Consumer
    public final void accept(Object object0) {
        String s = (String)object0;
    }
}

