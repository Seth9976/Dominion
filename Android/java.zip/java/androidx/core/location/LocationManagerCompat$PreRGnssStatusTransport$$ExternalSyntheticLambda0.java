package androidx.core.location;

import java.util.concurrent.Executor;

public final class LocationManagerCompat.PreRGnssStatusTransport..ExternalSyntheticLambda0 implements Runnable {
    public final PreRGnssStatusTransport f$0;
    public final Executor f$1;
    public final int f$2;

    public LocationManagerCompat.PreRGnssStatusTransport..ExternalSyntheticLambda0(PreRGnssStatusTransport locationManagerCompat$PreRGnssStatusTransport0, Executor executor0, int v) {
        this.f$0 = locationManagerCompat$PreRGnssStatusTransport0;
        this.f$1 = executor0;
        this.f$2 = v;
    }

    @Override
    public final void run() {
    }
}

