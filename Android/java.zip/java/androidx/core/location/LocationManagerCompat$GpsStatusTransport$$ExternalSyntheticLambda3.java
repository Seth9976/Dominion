package androidx.core.location;

import java.util.concurrent.Executor;

public final class LocationManagerCompat.GpsStatusTransport..ExternalSyntheticLambda3 implements Runnable {
    public final GpsStatusTransport f$0;
    public final Executor f$1;
    public final GnssStatusCompat f$2;

    public LocationManagerCompat.GpsStatusTransport..ExternalSyntheticLambda3(GpsStatusTransport locationManagerCompat$GpsStatusTransport0, Executor executor0, GnssStatusCompat gnssStatusCompat0) {
        this.f$0 = locationManagerCompat$GpsStatusTransport0;
        this.f$1 = executor0;
        this.f$2 = gnssStatusCompat0;
    }

    @Override
    public final void run() {
    }
}

