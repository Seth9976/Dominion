package androidx.core.location;

import java.util.concurrent.Executor;

public final class LocationManagerCompat.GpsStatusTransport..ExternalSyntheticLambda2 implements Runnable {
    public final GpsStatusTransport f$0;
    public final Executor f$1;
    public final int f$2;

    public LocationManagerCompat.GpsStatusTransport..ExternalSyntheticLambda2(GpsStatusTransport locationManagerCompat$GpsStatusTransport0, Executor executor0, int v) {
        this.f$0 = locationManagerCompat$GpsStatusTransport0;
        this.f$1 = executor0;
        this.f$2 = v;
    }

    @Override
    public final void run() {
    }
}

