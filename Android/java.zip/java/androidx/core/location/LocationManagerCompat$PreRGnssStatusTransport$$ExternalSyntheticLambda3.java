package androidx.core.location;

import java.util.concurrent.Executor;

public final class LocationManagerCompat.PreRGnssStatusTransport..ExternalSyntheticLambda3 implements Runnable {
    public final PreRGnssStatusTransport f$0;
    public final Executor f$1;

    public LocationManagerCompat.PreRGnssStatusTransport..ExternalSyntheticLambda3(PreRGnssStatusTransport locationManagerCompat$PreRGnssStatusTransport0, Executor executor0) {
        this.f$0 = locationManagerCompat$PreRGnssStatusTransport0;
        this.f$1 = executor0;
    }

    @Override
    public final void run() {
    }
}

