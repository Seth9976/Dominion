package androidx.core.util;

public interface Supplier {
    Object get();
}

