package androidx.core.util;

public final class Predicate..ExternalSyntheticBackport0 {
    public static boolean m(Object object0) {
        return object0 == null;
    }
}

