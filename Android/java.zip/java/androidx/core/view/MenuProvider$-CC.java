package androidx.core.view;

import android.view.Menu;

public final class MenuProvider.-CC {
    public static void $default$onMenuClosed(MenuProvider _this, Menu menu0) {
    }

    public static void $default$onPrepareMenu(MenuProvider _this, Menu menu0) {
    }
}

