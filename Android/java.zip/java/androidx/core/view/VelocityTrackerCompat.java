package androidx.core.view;

import android.view.VelocityTracker;

@Deprecated
public final class VelocityTrackerCompat {
    @Deprecated
    public static float getXVelocity(VelocityTracker velocityTracker0, int v) {
        return velocityTracker0.getXVelocity(v);
    }

    @Deprecated
    public static float getYVelocity(VelocityTracker velocityTracker0, int v) {
        return velocityTracker0.getYVelocity(v);
    }
}

