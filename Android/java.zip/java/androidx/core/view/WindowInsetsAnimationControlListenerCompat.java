package androidx.core.view;

public interface WindowInsetsAnimationControlListenerCompat {
    void onCancelled(WindowInsetsAnimationControllerCompat arg1);

    void onFinished(WindowInsetsAnimationControllerCompat arg1);

    void onReady(WindowInsetsAnimationControllerCompat arg1, int arg2);
}

