package androidx.core.view;

public final class ViewCompat..ExternalSyntheticLambda1 implements OnReceiveContentViewBehavior {
    @Override  // androidx.core.view.OnReceiveContentViewBehavior
    public final ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat0) {
        return contentInfoCompat0;
    }
}

