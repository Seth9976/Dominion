package androidx.core.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    @Override  // androidx.core.view.ViewPropertyAnimatorListener
    public void onAnimationCancel(View view0) {
    }

    @Override  // androidx.core.view.ViewPropertyAnimatorListener
    public void onAnimationEnd(View view0) {
    }

    @Override  // androidx.core.view.ViewPropertyAnimatorListener
    public void onAnimationStart(View view0) {
    }
}

