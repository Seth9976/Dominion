package androidx.core.view;

import android.view.View;

public interface OnApplyWindowInsetsListener {
    WindowInsetsCompat onApplyWindowInsets(View arg1, WindowInsetsCompat arg2);
}

