package androidx.core.view;

import android.view.View.OnLongClickListener;
import android.view.View;

public final class DragStartHelper..ExternalSyntheticLambda0 implements View.OnLongClickListener {
    public final DragStartHelper f$0;

    public DragStartHelper..ExternalSyntheticLambda0(DragStartHelper dragStartHelper0) {
        this.f$0 = dragStartHelper0;
    }

    @Override  // android.view.View$OnLongClickListener
    public final boolean onLongClick(View view0) {
        return this.f$0.onLongClick(view0);
    }
}

