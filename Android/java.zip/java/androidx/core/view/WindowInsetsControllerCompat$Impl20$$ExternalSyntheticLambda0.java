package androidx.core.view;

import android.view.View;

public final class WindowInsetsControllerCompat.Impl20..ExternalSyntheticLambda0 implements Runnable {
    public final View f$0;

    public WindowInsetsControllerCompat.Impl20..ExternalSyntheticLambda0(View view0) {
        this.f$0 = view0;
    }

    @Override
    public final void run() {
        Impl20.lambda$showForType$0(this.f$0);
    }
}

