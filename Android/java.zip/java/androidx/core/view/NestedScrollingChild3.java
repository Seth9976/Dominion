package androidx.core.view;

public interface NestedScrollingChild3 extends NestedScrollingChild2 {
    void dispatchNestedScroll(int arg1, int arg2, int arg3, int arg4, int[] arg5, int arg6, int[] arg7);
}

