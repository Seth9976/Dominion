package androidx.core.view;

import android.view.View;

public interface NestedScrollingParent3 extends NestedScrollingParent2 {
    void onNestedScroll(View arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int[] arg7);
}

