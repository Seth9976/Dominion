package androidx.core.app;

import android.app.Activity;

public final class ActivityCompat..ExternalSyntheticLambda0 implements Runnable {
    public final Activity f$0;

    public ActivityCompat..ExternalSyntheticLambda0(Activity activity0) {
        this.f$0 = activity0;
    }

    @Override
    public final void run() {
        ActivityCompat.lambda$recreate$0(this.f$0);
    }
}

