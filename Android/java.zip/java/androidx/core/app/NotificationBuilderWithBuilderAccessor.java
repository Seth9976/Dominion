package androidx.core.app;

import android.app.Notification.Builder;

public interface NotificationBuilderWithBuilderAccessor {
    Notification.Builder getBuilder();
}

