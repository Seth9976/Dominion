package androidx.core.text.util;

import java.util.Comparator;

public final class LinkifyCompat..ExternalSyntheticLambda0 implements Comparator {
    @Override
    public final int compare(Object object0, Object object1) {
        return LinkifyCompat.lambda$static$0(((LinkSpec)object0), ((LinkSpec)object1));
    }
}

