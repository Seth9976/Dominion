package androidx.core.provider;

import java.util.Comparator;

public final class FontProvider..ExternalSyntheticLambda0 implements Comparator {
    @Override
    public final int compare(Object object0, Object object1) {
        return FontProvider.lambda$static$0(((byte[])object0), ((byte[])object1));
    }
}

