package androidx.core.widget;

public final class ContentLoadingProgressBar..ExternalSyntheticLambda0 implements Runnable {
    public final ContentLoadingProgressBar f$0;

    public ContentLoadingProgressBar..ExternalSyntheticLambda0(ContentLoadingProgressBar contentLoadingProgressBar0) {
        this.f$0 = contentLoadingProgressBar0;
    }

    @Override
    public final void run() {
        this.f$0.lambda$new$0$androidx-core-widget-ContentLoadingProgressBar();
    }
}

