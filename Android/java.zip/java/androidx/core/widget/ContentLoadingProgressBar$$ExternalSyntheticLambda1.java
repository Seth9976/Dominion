package androidx.core.widget;

public final class ContentLoadingProgressBar..ExternalSyntheticLambda1 implements Runnable {
    public final ContentLoadingProgressBar f$0;

    public ContentLoadingProgressBar..ExternalSyntheticLambda1(ContentLoadingProgressBar contentLoadingProgressBar0) {
        this.f$0 = contentLoadingProgressBar0;
    }

    @Override
    public final void run() {
        this.f$0.lambda$new$1$androidx-core-widget-ContentLoadingProgressBar();
    }
}

