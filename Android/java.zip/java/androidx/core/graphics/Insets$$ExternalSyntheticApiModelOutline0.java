package androidx.core.graphics;

import android.app.NotificationChannelGroup;
import android.content.Context;
import android.content.pm.ShortcutInfo.Builder;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.location.GnssStatus;
import android.location.LocationRequest;
import android.os.LocaleList;

public final class Insets..ExternalSyntheticApiModelOutline0 {
    public static NotificationChannelGroup m(Object object0) [...] // Inlined contents

    public static ShortcutInfo.Builder m(Context context0, String s) {
        return new ShortcutInfo.Builder(context0, s);
    }

    public static ShortcutInfo m(Object object0) [...] // Inlined contents

    public static ShortcutManager m(Object object0) {
        return (ShortcutManager)object0;
    }

    public static GnssStatus m(Object object0) [...] // Inlined contents

    public static LocationRequest m(Object object0) {
        return (LocationRequest)object0;
    }

    public static LocaleList m(Object object0) [...] // Inlined contents

    public static void m() {
    }
}

