// 函数: _fprintf
// 地址: 0x5ca1a0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t var_18 = data_19e39ac
void _ArgList
return __stdio_common_vfscanf(data_19e39a8, arg1, arg2, nullptr, &_ArgList)
