// 函数: ___scrt_initialize_crt
// 地址: 0x759485
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

if (arg1 == 0)
    data_cc89e8 = 1

int64_t xcr0
sub_759d0c(xcr0)

if (sub_4ab040() != 0 && sub_4ab040() != 0)
    return 1

return 0
