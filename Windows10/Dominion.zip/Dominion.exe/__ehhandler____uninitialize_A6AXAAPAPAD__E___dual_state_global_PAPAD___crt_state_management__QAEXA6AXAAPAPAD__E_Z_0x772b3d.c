// 函数: __ehhandler$??$uninitialize@A6AXAAPAPAD@_E@?$dual_state_global@PAPAD@__crt_state_management@@QAEXA6AXAAPAPAD@_E@Z
// 地址: 0x772b3d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff4).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bf864, arg1, ecx_1) __tailcall
