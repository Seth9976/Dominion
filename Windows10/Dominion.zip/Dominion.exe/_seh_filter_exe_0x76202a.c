// 函数: _seh_filter_exe
// 地址: 0x76202a
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _seh_filter_exe(_ExceptionNum, _ExceptionPtr) __tailcall
