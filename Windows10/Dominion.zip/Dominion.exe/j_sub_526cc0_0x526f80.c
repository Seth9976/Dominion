// 函数: j_sub_526cc0
// 地址: 0x526f80
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_526cc0() __tailcall
