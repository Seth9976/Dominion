// 函数: ?_Incref@facet@locale@std@@UAEXXZ
// 地址: 0x7591f7
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return std::locale::facet::_Incref(this) __tailcall
