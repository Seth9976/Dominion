// 函数: sub_401390
// 地址: 0x401390
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db788, "gameCreate")
