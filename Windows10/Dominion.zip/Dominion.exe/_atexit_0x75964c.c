// 函数: _atexit
// 地址: 0x75964c
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

_PVFV eax = __onexit(arg1)
int32_t eax_1 = neg.d(eax)
return neg.d(sbb.d(eax_1, eax_1, eax != 0)) - 1
