// 函数: j_sub_6fc940
// 地址: 0x6fd300
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_6fc940() __tailcall
