// 函数: __ehhandler$?_Getifld@?$num_get@DV?$istreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@ABAHPADAAV?$istreambuf_iterator@DU?$char_traits@D@std@@@2@1HABVlocale@2@@Z
// 地址: 0x765418
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1->__offset(0xffffffffffffff58).d
CookieCheckFunction(&arg1[1])
int32_t ecx_3 = arg1->__offset(0xfffffffffffffffc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b1528, arg1, ecx_3) __tailcall
