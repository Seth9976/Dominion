// 函数: copysignf
// 地址: 0x7623a4
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return copysignf(arg1, arg2) __tailcall
