// 函数: _libm_sse2_asin_precise
// 地址: 0x762380
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _libm_sse2_asin_precise(arg1, arg2, arg3, arg4, arg5) __tailcall
