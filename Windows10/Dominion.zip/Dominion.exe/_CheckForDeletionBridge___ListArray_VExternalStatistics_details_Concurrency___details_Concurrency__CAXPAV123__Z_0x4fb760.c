// 函数: ?CheckForDeletionBridge@?$ListArray@VExternalStatistics@details@Concurrency@@@details@Concurrency@@CAXPAV123@@Z
// 地址: 0x4fb760
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_56f260(arg1) __tailcall
