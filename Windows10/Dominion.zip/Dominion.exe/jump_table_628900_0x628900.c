// 函数: jump_table_628900
// 地址: 0x628900
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t var_4 = arg1
char temp0 = *arg2
*arg2 = arg1:1.b
arg1:1.b = temp0
char temp0_1 = *arg2
*arg2 = sx.d(arg1.w):1.b
int32_t eax
eax:1.b = temp0_1
*arg3 = eax.b
void* edi = &arg3[1]
char temp0_2 = *arg2
*arg2 = eax:1.b
eax:1.b = temp0_2
int32_t eflags
int32_t eflags_1
int32_t eip
eip, eflags_1 = __into(eflags)
char temp0_3 = *arg2
*arg2 = eax:1.b
eax:1.b = temp0_3
char temp0_4 = *arg2
*arg2 = eax:1.b
eax:1.b = temp0_4
eax.b -= 0x79
__bound_gprv_mema32(eax, *eax)
int16_t ss
uint32_t var_8 = zx.d(ss)
char temp0_5 = *arg2
*arg2 = &var_8
int32_t* esp = temp0_5
*(edi - 0x78b3ff9e) -= eax.b
__bound_gprv_mema32(eax, *eax)
*esp
char temp0_6 = *arg2
*arg2 = &esp[1]
*arg2
*arg2 = temp0_6
undefined
