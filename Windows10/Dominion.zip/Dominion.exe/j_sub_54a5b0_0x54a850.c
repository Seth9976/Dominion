// 函数: j_sub_54a5b0
// 地址: 0x54a850
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_54a5b0(arg1) __tailcall
