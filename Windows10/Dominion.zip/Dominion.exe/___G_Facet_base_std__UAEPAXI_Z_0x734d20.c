// 函数: ??_G_Facet_base@std@@UAEPAXI@Z
// 地址: 0x734d20
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = &data_88ef20

if ((arg2 & 1) != 0)
    int32_t var_c_1 = 4
    operator new(arg1)

return arg1
