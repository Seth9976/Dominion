// 函数: j_sub_63d040
// 地址: 0x63cc30
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_63d040(arg1) __tailcall
