// 函数: ??0TI_OFF@@QAE@XZ
// 地址: 0x5bc0e0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = 0
arg1[1] = 0
return arg1
