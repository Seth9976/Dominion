// 函数: __chkstk
// 地址: 0x761e50
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

void* ecx_1 = (&__return_addr - arg1) & not.d(sbb.d(arg1, arg1, &__return_addr u< arg1))
int32_t __saved_ecx
void* eax_2 = &__saved_ecx & 0xfffff000

while (ecx_1 u< eax_2)
    eax_2 -= 0x1000
    *eax_2

void* const result = __return_addr
*ecx_1 = result
return result
