// 函数: _except_handler4_common
// 地址: 0x761fd6
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _except_handler4_common(CookiePointer, CookieCheckFunction, ExceptionRecord, 
    EstablisherFrame, ContextRecord, DispatcherContext) __tailcall
