// 函数: sub_401320
// 地址: 0x401320
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db574, "timerString")
data_8db574 = &UI2StateDeclText::`vftable'{for `UI2StateDecl'}
return result
