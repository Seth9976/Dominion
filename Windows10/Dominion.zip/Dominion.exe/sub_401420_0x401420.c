// 函数: sub_401420
// 地址: 0x401420
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _atexit(x434b916e::_ExceptionPtr_static<class std::bad_exception>::operator[]::_ExceptionPtr_static<class std::bad_exception>::_ExceptionPtr_static<class std::bad_exception>)
