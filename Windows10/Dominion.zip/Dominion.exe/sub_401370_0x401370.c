// 函数: sub_401370
// 地址: 0x401370
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _atexit(sub_773570)
