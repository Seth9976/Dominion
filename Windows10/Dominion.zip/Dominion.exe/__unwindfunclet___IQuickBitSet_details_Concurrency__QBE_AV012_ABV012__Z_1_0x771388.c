// 函数: __unwindfunclet$??IQuickBitSet@details@Concurrency@@QBE?AV012@ABV012@@Z$1
// 地址: 0x771388
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = *(arg1 - 0x18) & 1

if (result == 0)
    return result

*(arg1 - 0x18) &= 0xfffffffe
return sub_4ab280(*(arg1 + 8)) __tailcall
