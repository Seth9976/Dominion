// 函数: _libm_sse2_cos_precise
// 地址: 0x76209c
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _libm_sse2_cos_precise(arg1, arg2, arg3) __tailcall
