// 函数: ?__abi_winrt_ptrto_string_dtor@@YAXQ$ADVString@Platform@@@Z
// 地址: 0x4d2020
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4d1e40(arg1)
