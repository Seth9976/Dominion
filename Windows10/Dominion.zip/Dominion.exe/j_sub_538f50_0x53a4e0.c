// 函数: j_sub_538f50
// 地址: 0x53a4e0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_538f50() __tailcall
