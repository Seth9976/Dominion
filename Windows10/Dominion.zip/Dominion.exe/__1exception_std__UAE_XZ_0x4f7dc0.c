// 函数: ??1exception@std@@UAE@XZ
// 地址: 0x4f7dc0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = &std::exception::`vftable'
return __std_exception_destroy(&arg1[1])
