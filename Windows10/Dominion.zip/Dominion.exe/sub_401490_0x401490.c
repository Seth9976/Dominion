// 函数: sub_401490
// 地址: 0x401490
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db82c, "invitePending")
