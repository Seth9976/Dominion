// 函数: __p__commode
// 地址: 0x762072
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return __p__commode() __tailcall
