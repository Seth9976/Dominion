// 函数: sub_401510
// 地址: 0x401510
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db88c, "playerGuest")
