// 函数: _initialize_onexit_table
// 地址: 0x76200c
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _initialize_onexit_table(_Table) __tailcall
