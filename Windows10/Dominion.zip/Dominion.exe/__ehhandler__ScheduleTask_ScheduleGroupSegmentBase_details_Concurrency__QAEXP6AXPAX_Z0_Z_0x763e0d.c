// 函数: __ehhandler$?ScheduleTask@ScheduleGroupSegmentBase@details@Concurrency@@QAEXP6AXPAX@Z0@Z
// 地址: 0x763e0d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffb0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8afd48, arg1, ecx_1) __tailcall
