// 函数: ??_U@YAPAXIHPBDH@Z
// 地址: 0x7597ab
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_7597b9(arg1)
