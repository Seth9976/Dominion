// 函数: _configure_narrow_argv
// 地址: 0x762000
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _configure_narrow_argv(mode) __tailcall
