// 函数: __unwindfunclet$?Dispatch@InternalContextBase@details@Concurrency@@UAEXPAUDispatchState@3@@Z$0
// 地址: 0x762aa0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = *(arg1 - 0x18) & 1

if (result == 0)
    return result

*(arg1 - 0x18) &= 0xfffffffe
return sub_4ab280(arg1 - 0x3c) __tailcall
