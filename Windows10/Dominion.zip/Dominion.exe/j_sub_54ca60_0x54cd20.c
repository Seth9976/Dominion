// 函数: j_sub_54ca60
// 地址: 0x54cd20
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_54ca60(arg1) __tailcall
