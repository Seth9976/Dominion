// 函数: _register_thread_local_exe_atexit_callback
// 地址: 0x762060
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _register_thread_local_exe_atexit_callback(_Callback) __tailcall
