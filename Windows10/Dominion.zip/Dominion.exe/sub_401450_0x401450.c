// 函数: sub_401450
// 地址: 0x401450
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db814, "playerNameProfile")
data_8db814 = &UI2StateDeclText::`vftable'{for `UI2StateDecl'}
return result
