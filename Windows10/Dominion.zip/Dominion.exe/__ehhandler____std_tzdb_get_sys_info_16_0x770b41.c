// 函数: __ehhandler$___std_tzdb_get_sys_info@16
// 地址: 0x770b41
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffff70).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bd240, arg1, ecx_1) __tailcall
