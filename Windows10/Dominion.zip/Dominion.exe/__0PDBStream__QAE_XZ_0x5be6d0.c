// 函数: ??0PDBStream@@QAE@XZ
// 地址: 0x5be6d0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = 0
arg1[1] = 0
arg1[2] = 0
return arg1
