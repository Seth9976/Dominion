// 函数: j_sub_56ae20
// 地址: 0x55ecd0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_56ae20(arg1) __tailcall
