// 函数: ?AddRef@IStreamFileCRTAPI@@UAGKXZ
// 地址: 0x761590
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t eax = *(arg1 + 8)
*(arg1 + 8) += 1
return eax + 1
