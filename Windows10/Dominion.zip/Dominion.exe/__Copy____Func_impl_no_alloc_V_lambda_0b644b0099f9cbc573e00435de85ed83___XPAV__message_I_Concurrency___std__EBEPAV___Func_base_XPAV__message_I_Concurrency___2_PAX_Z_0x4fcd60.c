// 函数: ?_Copy@?$_Func_impl_no_alloc@V<lambda_0b644b0099f9cbc573e00435de85ed83>@@XPAV?$message@I@Concurrency@@@std@@EBEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x4fcd60
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_2af886436c63691486eaa2a71e17431b>,bool,enum CardID>::`vftable'{for `std::_Func_base<bool,enum CardID>'}
arg2[1] = *(arg1 + 4)
return arg2
