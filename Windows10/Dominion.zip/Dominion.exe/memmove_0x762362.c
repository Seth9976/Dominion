// 函数: memmove
// 地址: 0x762362
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return memmove(dest, src, count) __tailcall
