// 函数: ?what@exception@stdext@@UBEPBDXZ
// 地址: 0x4f7ea0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

char* result = *(arg1 + 4)

if (result != 0)
    return result

return "Unknown exception"
