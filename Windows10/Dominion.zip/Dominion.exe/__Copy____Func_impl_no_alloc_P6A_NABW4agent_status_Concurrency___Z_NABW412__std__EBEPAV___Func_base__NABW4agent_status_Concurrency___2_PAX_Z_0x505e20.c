// 函数: ?_Copy@?$_Func_impl_no_alloc@P6A_NABW4agent_status@Concurrency@@@Z_NABW412@@std@@EBEPAV?$_Func_base@_NABW4agent_status@Concurrency@@@2@PAX@Z
// 地址: 0x505e20
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_e16ff1a20f76c9913c6044854cd52f23>,bool,enum CardID>::`vftable'{for `std::_Func_base<bool,enum CardID>'}
arg2[1] = *(arg1 + 4)
return arg2
