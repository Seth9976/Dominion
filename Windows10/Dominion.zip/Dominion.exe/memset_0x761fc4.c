// 函数: memset
// 地址: 0x761fc4
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return memset(dest, c, count) __tailcall
