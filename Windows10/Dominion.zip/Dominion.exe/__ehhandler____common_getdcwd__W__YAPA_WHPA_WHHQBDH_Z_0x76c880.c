// 函数: __ehhandler$??$common_getdcwd@_W@@YAPA_WHPA_WHHQBDH@Z
// 地址: 0x76c880
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1->__offset(0xffffffffffffff78).d
CookieCheckFunction(&arg1[1])
int32_t ecx_3 = arg1->__offset(0xfffffffffffffffc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b8a94, arg1, ecx_3) __tailcall
