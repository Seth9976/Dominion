// 函数: _crt_atexit
// 地址: 0x762018
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _crt_atexit(_Function) __tailcall
