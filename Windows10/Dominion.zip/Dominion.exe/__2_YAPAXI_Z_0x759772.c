// 函数: ??2@YAPAXI@Z
// 地址: 0x759772
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t i

do
    int32_t result = malloc(arg1)
    
    if (result != 0)
        return result
    
    i = _callnewh(arg1)
while (i != 0)

if (arg1 == 0xffffffff)
    noreturn sub_4f7ee0() __tailcall

noreturn sub_5b0890() __tailcall
