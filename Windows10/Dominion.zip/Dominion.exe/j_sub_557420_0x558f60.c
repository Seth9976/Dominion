// 函数: j_sub_557420
// 地址: 0x558f60
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_557420(arg1) __tailcall
