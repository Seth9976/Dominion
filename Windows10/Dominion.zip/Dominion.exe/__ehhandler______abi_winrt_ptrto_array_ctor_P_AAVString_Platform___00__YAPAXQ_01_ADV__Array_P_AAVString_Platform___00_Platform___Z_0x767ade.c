// 函数: __ehhandler$??$__abi_winrt_ptrto_array_ctor@P$AAVString@Platform@@$00@@YAPAXQ$01$ADV?$Array@P$AAVString@Platform@@$00@Platform@@@Z
// 地址: 0x767ade
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffdc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b3498, arg1, ecx_1) __tailcall
