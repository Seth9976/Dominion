// 函数: sub_401570
// 地址: 0x401570
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db8c8, "img_playerAvatar")
data_8db8c8 = &UI2StateDeclImage::`vftable'{for `UI2StateDecl'}
return result
