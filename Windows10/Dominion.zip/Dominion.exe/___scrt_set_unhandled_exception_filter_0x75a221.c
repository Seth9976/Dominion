// 函数: ___scrt_set_unhandled_exception_filter
// 地址: 0x75a221
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return SetUnhandledExceptionFilter(___scrt_unhandled_exception_filter@4)
