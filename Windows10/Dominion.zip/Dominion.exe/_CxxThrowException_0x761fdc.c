// 函数: _CxxThrowException
// 地址: 0x761fdc
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

noreturn _CxxThrowException(pExceptionObject, pThrowInfo) __tailcall
