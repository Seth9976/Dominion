// 函数: __allmul
// 地址: 0x7621d0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

if ((arg4 | arg2) == 0)
    return arg1 * arg3

int32_t result
int32_t edx
edx:result = mulu.dp.d(arg1, arg3)
return result
