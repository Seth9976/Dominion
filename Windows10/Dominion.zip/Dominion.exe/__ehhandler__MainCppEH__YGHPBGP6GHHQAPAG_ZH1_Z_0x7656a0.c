// 函数: __ehhandler$?MainCppEH@@YGHPBGP6GHHQAPAG@ZH1@Z
// 地址: 0x7656a0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8adfd0, arg1, ecx_1) __tailcall
