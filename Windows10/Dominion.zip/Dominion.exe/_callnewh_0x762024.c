// 函数: _callnewh
// 地址: 0x762024
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _callnewh(_Size) __tailcall
