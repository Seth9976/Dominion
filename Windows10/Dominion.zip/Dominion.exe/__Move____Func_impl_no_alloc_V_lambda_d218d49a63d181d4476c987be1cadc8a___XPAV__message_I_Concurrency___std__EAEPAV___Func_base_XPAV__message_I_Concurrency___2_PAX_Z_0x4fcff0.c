// 函数: ?_Move@?$_Func_impl_no_alloc@V<lambda_d218d49a63d181d4476c987be1cadc8a>@@XPAV?$message@I@Concurrency@@@std@@EAEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x4fcff0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_142ce6dde16d404f2ad6d27cc72f7c37>, void>::`vftable'{for `std::_Func_base<void>'}
arg2[1] = *(arg1 + 4)
return arg2
