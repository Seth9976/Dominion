// 函数: __ehhandler$??$__acrt_lowio_lock_fh_and_call@V<lambda_7253ddea65725dd1b0d958044d9596be>@@@@YAHH$$QAV<lambda_7253ddea65725dd1b0d958044d9596be>@@@Z
// 地址: 0x77193e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8be330, arg1, ecx_1) __tailcall
