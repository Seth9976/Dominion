// 函数: __ehhandler$??$_Emplace_reallocate@UGSISymbolEntry@@@?$vector@UGSISymbolEntry@@V?$allocator@UGSISymbolEntry@@@std@@@std@@QAEPAUGSISymbolEntry@@QAU2@$$QAU2@@Z
// 地址: 0x76439e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffd8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b02f8, arg1, ecx_1) __tailcall
