// 函数: __ehhandler$??$__acrt_lock_and_call@V<lambda_b8d4b9c228a6ecc3f80208dbb4b4a104>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_b8d4b9c228a6ecc3f80208dbb4b4a104>@@@Z
// 地址: 0x7725a5
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bf1ac, arg1, ecx_1) __tailcall
