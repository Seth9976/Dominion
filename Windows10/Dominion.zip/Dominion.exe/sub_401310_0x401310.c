// 函数: sub_401310
// 地址: 0x401310
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db568, "showTimer")
