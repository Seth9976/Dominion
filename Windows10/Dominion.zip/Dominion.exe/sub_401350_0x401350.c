// 函数: sub_401350
// 地址: 0x401350
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db58c, "timerStringOpp")
data_8db58c = &UI2StateDeclText::`vftable'{for `UI2StateDecl'}
return result
