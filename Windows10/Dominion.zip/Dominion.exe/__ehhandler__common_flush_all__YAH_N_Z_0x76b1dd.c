// 函数: __ehhandler$?common_flush_all@@YAH_N@Z
// 地址: 0x76b1dd
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe4).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b7304, arg1, ecx_1) __tailcall
