// 函数: ___scrt_uninitialize_crt
// 地址: 0x7595f6
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

if (data_cc89e8 == 0 || arg2 == 0)
    int32_t var_8_1 = arg1
    int32_t var_c_1 = arg1

int32_t result
result.b = 1
return result
