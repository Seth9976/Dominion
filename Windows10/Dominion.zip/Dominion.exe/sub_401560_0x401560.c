// 函数: sub_401560
// 地址: 0x401560
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db8bc, "playerUntoggleable")
