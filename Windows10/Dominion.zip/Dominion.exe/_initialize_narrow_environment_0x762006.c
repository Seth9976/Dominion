// 函数: _initialize_narrow_environment
// 地址: 0x762006
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _initialize_narrow_environment() __tailcall
