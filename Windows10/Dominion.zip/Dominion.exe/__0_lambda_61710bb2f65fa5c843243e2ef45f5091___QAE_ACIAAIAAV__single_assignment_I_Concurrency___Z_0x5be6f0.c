// 函数: ??0<lambda_61710bb2f65fa5c843243e2ef45f5091>@@QAE@ACIAAIAAV?$single_assignment@I@Concurrency@@@Z
// 地址: 0x5be6f0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = arg2
arg1[1] = arg3
arg1[2] = arg4
return arg1
