// 函数: sub_4014d0
// 地址: 0x4014d0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db85c, "playerHuman")
