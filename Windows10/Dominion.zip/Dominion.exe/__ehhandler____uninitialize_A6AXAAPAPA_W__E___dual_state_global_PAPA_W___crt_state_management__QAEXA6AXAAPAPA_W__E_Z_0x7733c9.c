// 函数: __ehhandler$??$uninitialize@A6AXAAPAPA_W@_E@?$dual_state_global@PAPA_W@__crt_state_management@@QAEXA6AXAAPAPA_W@_E@Z
// 地址: 0x7733c9
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffec).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8c04b8, arg1, ecx_1) __tailcall
