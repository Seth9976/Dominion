// 函数: __ehhandler$??$common_fstat@U_stat32@@@@YAHHQAU_stat32@@@Z
// 地址: 0x763210
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1->__offset(0xffffffffffffffa4).d
CookieCheckFunction(&arg1[1])
int32_t ecx_3 = arg1->__offset(0xfffffffffffffffc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8af048, arg1, ecx_3) __tailcall
