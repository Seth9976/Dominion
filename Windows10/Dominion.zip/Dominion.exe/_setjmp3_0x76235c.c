// 函数: _setjmp3
// 地址: 0x76235c
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _setjmp3() __tailcall
