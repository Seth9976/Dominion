// 函数: _register_onexit_function
// 地址: 0x762012
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _register_onexit_function(_Table, _Function) __tailcall
