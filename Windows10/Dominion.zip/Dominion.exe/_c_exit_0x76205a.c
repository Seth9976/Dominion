// 函数: _c_exit
// 地址: 0x76205a
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _c_exit() __tailcall
