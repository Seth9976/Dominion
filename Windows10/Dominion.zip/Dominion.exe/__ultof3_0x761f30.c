// 函数: __ultof3
// 地址: 0x761f30
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

if ((data_8c4008 & 0x20) == 0)
    _mm_cvtepu64_ps(arg3.q, __vpinsrd_xmmdq_xmmdq_gpr32d_immb(zx.o(arg1), arg2, 1))
    return 

if (arg2 s< 0)
    uint32_t var_1c = arg2 u>> 1
    return 

if (arg2 == 0 && arg1 s>= 0)
    return 

uint32_t var_c = arg2
float var_10_1 = fconvert.s(float.t(arg1.q))
