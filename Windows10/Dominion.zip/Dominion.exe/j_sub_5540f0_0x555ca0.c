// 函数: j_sub_5540f0
// 地址: 0x555ca0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_5540f0(arg1) __tailcall
