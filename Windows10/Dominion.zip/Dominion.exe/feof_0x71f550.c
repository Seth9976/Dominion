// 函数: feof
// 地址: 0x71f550
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return feof(_Stream) __tailcall
