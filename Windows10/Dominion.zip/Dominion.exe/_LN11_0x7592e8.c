// 函数: $LN11
// 地址: 0x7592e8
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t entry_ebx

if (arg1 == 0)
    __ArrayUnwind(*(arg2 + 8), *(arg2 + 0xc), entry_ebx, *(arg2 + 0x18))
