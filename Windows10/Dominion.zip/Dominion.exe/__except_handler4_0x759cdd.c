// 函数: __except_handler4
// 地址: 0x759cdd
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t mxcsr
*arg1 = sub_7620a2(mxcsr, *arg1)
return _except_handler4_common(&__security_cookie, CookieCheckFunction, arg1, arg2, arg3, arg4)
