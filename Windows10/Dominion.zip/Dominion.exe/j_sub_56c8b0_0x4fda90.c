// 函数: j_sub_56c8b0
// 地址: 0x4fda90
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_56c8b0(arg1) __tailcall
