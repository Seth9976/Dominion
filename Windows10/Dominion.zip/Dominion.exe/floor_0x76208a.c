// 函数: floor
// 地址: 0x76208a
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return floor(_X) __tailcall
