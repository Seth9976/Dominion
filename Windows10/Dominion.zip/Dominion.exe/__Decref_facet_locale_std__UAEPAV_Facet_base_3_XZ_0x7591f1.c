// 函数: ?_Decref@facet@locale@std@@UAEPAV_Facet_base@3@XZ
// 地址: 0x7591f1
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return std::locale::facet::_Decref(this) __tailcall
