// 函数: j_sub_56c970
// 地址: 0x52dd50
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_56c970() __tailcall
