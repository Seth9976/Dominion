// 函数: __ehhandler$?push_back@TokenRegistrationContainer@_CancellationTokenState@details@Concurrency@@QAEXPAV_CancellationTokenRegistration@34@@Z
// 地址: 0x769b40
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b5918, arg1, ecx_1) __tailcall
