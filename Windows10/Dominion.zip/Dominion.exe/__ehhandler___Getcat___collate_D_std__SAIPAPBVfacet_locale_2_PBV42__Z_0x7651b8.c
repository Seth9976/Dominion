// 函数: __ehhandler$?_Getcat@?$collate@D@std@@SAIPAPBVfacet@locale@2@PBV42@@Z
// 地址: 0x7651b8
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1->__offset(0xffffffffffffff94).d
CookieCheckFunction(&arg1[1])
int32_t ecx_3 = arg1->__offset(0xfffffffffffffffc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b1388, arg1, ecx_3) __tailcall
