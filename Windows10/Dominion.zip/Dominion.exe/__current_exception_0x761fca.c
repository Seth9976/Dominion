// 函数: __current_exception
// 地址: 0x761fca
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return __current_exception() __tailcall
