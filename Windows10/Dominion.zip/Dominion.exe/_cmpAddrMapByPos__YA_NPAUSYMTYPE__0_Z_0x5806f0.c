// 函数: ?cmpAddrMapByPos@@YA_NPAUSYMTYPE@@0@Z
// 地址: 0x5806f0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result
result.b = arg1 u< arg2
return result
