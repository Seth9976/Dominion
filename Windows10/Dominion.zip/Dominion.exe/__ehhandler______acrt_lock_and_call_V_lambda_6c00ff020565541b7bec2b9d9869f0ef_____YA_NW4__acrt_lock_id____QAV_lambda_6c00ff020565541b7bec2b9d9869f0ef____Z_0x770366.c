// 函数: __ehhandler$??$__acrt_lock_and_call@V<lambda_6c00ff020565541b7bec2b9d9869f0ef>@@@@YA_NW4__acrt_lock_id@@$$QAV<lambda_6c00ff020565541b7bec2b9d9869f0ef>@@@Z
// 地址: 0x770366
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bc9ec, arg1, ecx_1) __tailcall
