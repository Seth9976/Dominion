// 函数: __CxxFrameHandler3
// 地址: 0x761fa6
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return __CxxFrameHandler3(pExcept, pRN, pContext, pDC) __tailcall
