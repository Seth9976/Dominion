// 函数: sub_4013f0
// 地址: 0x4013f0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db7d0, "gameResume")
