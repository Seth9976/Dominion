// 函数: __ehhandler$??0?$function@$$A6A_NABI@Z@std@@QAE@ABV01@@Z
// 地址: 0x76260d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8ae090, arg1, ecx_1) __tailcall
