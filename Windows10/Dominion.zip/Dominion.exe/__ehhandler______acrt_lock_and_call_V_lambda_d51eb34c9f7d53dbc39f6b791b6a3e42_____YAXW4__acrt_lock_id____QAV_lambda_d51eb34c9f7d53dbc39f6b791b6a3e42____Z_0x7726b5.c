// 函数: __ehhandler$??$__acrt_lock_and_call@V<lambda_d51eb34c9f7d53dbc39f6b791b6a3e42>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_d51eb34c9f7d53dbc39f6b791b6a3e42>@@@Z
// 地址: 0x7726b5
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bf328, arg1, ecx_1) __tailcall
