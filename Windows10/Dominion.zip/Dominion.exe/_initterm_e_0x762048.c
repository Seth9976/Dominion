// 函数: _initterm_e
// 地址: 0x762048
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _initterm_e(_First, _Last) __tailcall
