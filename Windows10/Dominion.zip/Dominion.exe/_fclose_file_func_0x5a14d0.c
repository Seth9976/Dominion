// 函数: _fclose_file_func
// 地址: 0x5a14d0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return malloc(arg1)
