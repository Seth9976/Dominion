// 函数: ceil
// 地址: 0x76239e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return ceil(_X) __tailcall
