// 函数: __ehhandler$?accumulate_inheritable_handles@@YA_NQAPAEQAI_N@Z
// 地址: 0x76e078
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8ba354, arg1, ecx_1) __tailcall
