// 函数: j_sub_53bef0
// 地址: 0x540c80
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_53bef0(arg1) __tailcall
