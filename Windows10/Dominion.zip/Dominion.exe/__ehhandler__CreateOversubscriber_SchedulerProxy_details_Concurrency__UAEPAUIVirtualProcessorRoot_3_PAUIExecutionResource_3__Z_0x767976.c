// 函数: __ehhandler$?CreateOversubscriber@SchedulerProxy@details@Concurrency@@UAEPAUIVirtualProcessorRoot@3@PAUIExecutionResource@3@@Z
// 地址: 0x767976
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffd8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b3378, arg1, ecx_1) __tailcall
