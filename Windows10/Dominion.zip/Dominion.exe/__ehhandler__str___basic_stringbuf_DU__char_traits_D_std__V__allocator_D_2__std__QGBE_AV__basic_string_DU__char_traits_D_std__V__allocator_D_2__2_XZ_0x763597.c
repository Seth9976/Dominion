// 函数: __ehhandler$?str@?$basic_stringbuf@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QGBE?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@2@XZ
// 地址: 0x763597
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8af4d0, arg1, ecx_1) __tailcall
