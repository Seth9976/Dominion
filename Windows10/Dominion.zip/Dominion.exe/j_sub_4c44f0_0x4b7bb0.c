// 函数: j_sub_4c44f0
// 地址: 0x4b7bb0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4c44f0() __tailcall
