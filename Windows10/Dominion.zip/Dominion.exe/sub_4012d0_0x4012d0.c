// 函数: sub_4012d0
// 地址: 0x4012d0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db544, "cardsetShowCounts")
