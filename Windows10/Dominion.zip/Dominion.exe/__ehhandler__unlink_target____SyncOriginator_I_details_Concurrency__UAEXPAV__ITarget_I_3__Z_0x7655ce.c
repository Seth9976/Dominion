// 函数: __ehhandler$?unlink_target@?$_SyncOriginator@I@details@Concurrency@@UAEXPAV?$ITarget@I@3@@Z
// 地址: 0x7655ce
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffc4).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b16a8, arg1, ecx_1) __tailcall
