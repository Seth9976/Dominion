// 函数: sub_401590
// 地址: 0x401590
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db8d4, "img_playerMeAvatar")
data_8db8d4 = &UI2StateDeclImage::`vftable'{for `UI2StateDecl'}
return result
