// 函数: __ehhandler$?GetSubAllocator@SchedulerBase@details@Concurrency@@SAPAVSubAllocator@23@_N@Z
// 地址: 0x76400e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe4).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8afeec, arg1, ecx_1) __tailcall
