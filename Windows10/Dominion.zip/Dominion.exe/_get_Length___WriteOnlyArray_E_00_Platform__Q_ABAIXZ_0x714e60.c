// 函数: ?get@Length@?$WriteOnlyArray@E$00@Platform@@Q$ABAIXZ
// 地址: 0x714e60
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return *(arg1 + 0x14)
