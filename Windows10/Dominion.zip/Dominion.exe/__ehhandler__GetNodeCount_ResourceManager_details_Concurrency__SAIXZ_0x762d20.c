// 函数: __ehhandler$?GetNodeCount@ResourceManager@details@Concurrency@@SAIXZ
// 地址: 0x762d20
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8ae78c, arg1, ecx_1) __tailcall
