// 函数: _set_new_mode
// 地址: 0x76206c
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _set_new_mode(_NewMode) __tailcall
