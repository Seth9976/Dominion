// 函数: ?_Copy@?$_Func_impl_no_alloc@V<lambda_d218d49a63d181d4476c987be1cadc8a>@@XPAV?$message@I@Concurrency@@@std@@EBEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x4fe8b0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_6504ca0e3a159a0c1745db3fb8c837d1>, void>::`vftable'{for `std::_Func_base<void>'}
arg2[1] = *(arg1 + 4)
return arg2
