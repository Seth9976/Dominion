// 函数: __ehhandler$?_Push@_Micro_queue@details@Concurrency@@QAEXPAXIAAV_Concurrent_queue_base_v4@23@P8423@AEXAAU_Page@423@I0@Z@Z
// 地址: 0x7637a5
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffff9c).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8af758, arg1, ecx_1) __tailcall
