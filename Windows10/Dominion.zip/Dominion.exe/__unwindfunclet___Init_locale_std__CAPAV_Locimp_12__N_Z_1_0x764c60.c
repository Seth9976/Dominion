// 函数: __unwindfunclet$?_Init@locale@std@@CAPAV_Locimp@12@_N@Z$1
// 地址: 0x764c60
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t var_4 = 0xe4
return operator new(*(arg1 - 0x18))
