// 函数: __ehhandler$??$construct_environment_block@_W@@YAHQBQB_WQAPA_W@Z
// 地址: 0x764cdb
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1->__offset(0xffffffffffffff68).d
CookieCheckFunction(&arg1[1])
int32_t ecx_3 = arg1->__offset(0xfffffffffffffffc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b0ff4, arg1, ecx_3) __tailcall
