// 函数: j_sub_52c860
// 地址: 0x52caf0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_52c860(arg1) __tailcall
