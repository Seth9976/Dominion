// 函数: sub_401470
// 地址: 0x401470
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db820, "playerNameNext")
data_8db820 = &UI2StateDeclText::`vftable'{for `UI2StateDecl'}
return result
