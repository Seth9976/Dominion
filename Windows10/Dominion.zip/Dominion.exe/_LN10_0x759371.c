// 函数: $LN10
// 地址: 0x759371
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t entry_ebx

if (arg1 == 0)
    __ArrayUnwind(arg3, entry_ebx, arg4, *(arg2 + 0x14))
