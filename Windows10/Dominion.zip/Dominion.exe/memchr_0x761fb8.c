// 函数: memchr
// 地址: 0x761fb8
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return memchr(arg1, arg2, arg3) __tailcall
