// 函数: _get_narrow_winmain_command_line
// 地址: 0x76203c
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _get_narrow_winmain_command_line() __tailcall
