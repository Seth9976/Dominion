// 函数: __ehhandler$___std_smf_comp_ellint_3@16
// 地址: 0x76314d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffec).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8aeebc, arg1, ecx_1) __tailcall
