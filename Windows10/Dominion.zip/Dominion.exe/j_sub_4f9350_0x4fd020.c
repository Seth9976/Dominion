// 函数: j_sub_4f9350
// 地址: 0x4fd020
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4f9350() __tailcall
