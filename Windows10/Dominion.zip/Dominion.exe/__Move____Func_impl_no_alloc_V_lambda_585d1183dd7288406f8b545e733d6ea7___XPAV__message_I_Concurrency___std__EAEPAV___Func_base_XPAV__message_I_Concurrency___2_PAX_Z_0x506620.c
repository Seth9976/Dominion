// 函数: ?_Move@?$_Func_impl_no_alloc@V<lambda_585d1183dd7288406f8b545e733d6ea7>@@XPAV?$message@I@Concurrency@@@std@@EAEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x506620
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_373f7efe6097c805359c0ad40a413f4f>, void>::`vftable'{for `std::_Func_base<void>'}
arg2[1] = *(arg1 + 4)
return arg2
