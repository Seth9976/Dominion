// 函数: _ferror_file_func
// 地址: 0x5a14f0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return free(arg1)
