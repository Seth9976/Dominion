// 函数: sub_4015e0
// 地址: 0x4015e0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db8f8, "addMultiplayer")
