// 函数: __ehhandler$??$copy_wide_to_narrow_find_data@U_wfinddata64i32_t@@U_finddata64i32_t@@@@YA_NABU_wfinddata64i32_t@@AAU_finddata64i32_t@@I@Z
// 地址: 0x76c576
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffdc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b87b8, arg1, ecx_1) __tailcall
