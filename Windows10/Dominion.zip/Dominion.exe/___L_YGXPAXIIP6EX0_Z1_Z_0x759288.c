// 函数: ??_L@YGXPAXIIP6EX0@Z1@Z
// 地址: 0x759288
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t __saved_ebp_1 = 0x10
int32_t var_8 = 0x8c0408
enum _EXCEPTION_DISPOSITION (* var_10)(int32_t* arg1, struct _EXCEPTION_REGISTRATION_RECORD* arg2, 
    struct _CONTEXT* arg3, int32_t arg4) = __except_handler4
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
uint32_t __security_cookie_1 = __security_cookie
int32_t var_8_3 = 0x8c0408 ^ __security_cookie_1
int32_t __saved_ebp
int32_t var_34 = __security_cookie_1 ^ &__saved_ebp
int32_t* var_1c = &var_34
void* const var_38 = &data_759294
int32_t var_8_4 = 0xfffffffe
int32_t var_c = var_8_3
fsbase->NtTib.ExceptionList = &ExceptionList
int32_t ebx = 0
int32_t var_24 = 0
char var_1d = 0
int32_t var_8_1 = 0

while (ebx != arg3)
    arg4()
    arg1 += arg2
    ebx += 1
    int32_t var_24_1 = ebx

struct _EXCEPTION_REGISTRATION_RECORD** eax
eax.b = 1
char var_1d_1 = 1
int32_t var_8_2 = 0xfffffffe
int32_t result = $LN11(eax.b, &__saved_ebp)
fsbase->NtTib.ExceptionList = ExceptionList
return result
