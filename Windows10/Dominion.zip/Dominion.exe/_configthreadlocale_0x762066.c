// 函数: _configthreadlocale
// 地址: 0x762066
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _configthreadlocale(_Flag) __tailcall
