// 函数: __current_exception_context
// 地址: 0x761fd0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return __current_exception_context() __tailcall
