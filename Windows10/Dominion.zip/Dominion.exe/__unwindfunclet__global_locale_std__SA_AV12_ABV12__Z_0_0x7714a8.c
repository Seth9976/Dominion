// 函数: __unwindfunclet$?global@locale@std@@SA?AV12@ABV12@@Z$0
// 地址: 0x7714a8
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = *(arg1 - 0x10) & 1

if (result == 0)
    return result

*(arg1 - 0x10) &= 0xfffffffe
return sub_4ab280(*(arg1 + 8)) __tailcall
