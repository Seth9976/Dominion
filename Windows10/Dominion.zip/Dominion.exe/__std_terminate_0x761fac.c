// 函数: __std_terminate
// 地址: 0x761fac
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

noreturn __std_terminate() __tailcall
