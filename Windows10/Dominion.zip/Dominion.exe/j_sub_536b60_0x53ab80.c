// 函数: j_sub_536b60
// 地址: 0x53ab80
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_536b60(arg1, arg2) __tailcall
