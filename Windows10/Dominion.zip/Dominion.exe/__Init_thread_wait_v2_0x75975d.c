// 函数: __Init_thread_wait_v2
// 地址: 0x75975d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return SleepConditionVariableSRW(&data_cc8a04, &data_cc8a08, 0xffffffff, 0)
