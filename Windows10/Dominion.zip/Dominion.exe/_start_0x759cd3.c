// 函数: _start
// 地址: 0x759cd3
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

___security_init_cookie()
uint32_t esi
int32_t edi
return sub_759b57(esi, edi) __tailcall
