// 函数: j_sub_6fbf50
// 地址: 0x6fd230
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_6fbf50() __tailcall
