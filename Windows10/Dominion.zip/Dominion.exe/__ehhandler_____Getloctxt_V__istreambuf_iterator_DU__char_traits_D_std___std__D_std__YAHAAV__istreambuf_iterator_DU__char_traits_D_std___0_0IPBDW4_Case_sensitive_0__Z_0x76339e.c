// 函数: __ehhandler$??$_Getloctxt@V?$istreambuf_iterator@DU?$char_traits@D@std@@@std@@D@std@@YAHAAV?$istreambuf_iterator@DU?$char_traits@D@std@@@0@0IPBDW4_Case_sensitive@0@@Z
// 地址: 0x76339e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1->__offset(0xffffffffffffffa0).d
CookieCheckFunction(&arg1[1])
int32_t ecx_3 = arg1->__offset(0xfffffffffffffffc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8af254, arg1, ecx_3) __tailcall
