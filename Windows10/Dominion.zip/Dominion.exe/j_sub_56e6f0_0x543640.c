// 函数: j_sub_56e6f0
// 地址: 0x543640
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_56e6f0(arg1) __tailcall
