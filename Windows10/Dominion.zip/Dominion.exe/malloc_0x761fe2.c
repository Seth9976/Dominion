// 函数: malloc
// 地址: 0x761fe2
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return malloc(_Size) __tailcall
