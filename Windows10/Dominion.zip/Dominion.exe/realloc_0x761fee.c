// 函数: realloc
// 地址: 0x761fee
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return realloc(_Block, _Size) __tailcall
