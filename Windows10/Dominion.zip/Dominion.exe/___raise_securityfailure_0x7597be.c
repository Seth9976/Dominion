// 函数: ___raise_securityfailure
// 地址: 0x7597be
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

SetUnhandledExceptionFilter(0)
UnhandledExceptionFilter(arg1)
TerminateProcess(GetCurrentProcess(), 0xc0000409)
noreturn
