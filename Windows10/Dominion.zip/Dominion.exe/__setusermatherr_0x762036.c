// 函数: __setusermatherr
// 地址: 0x762036
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return __setusermatherr(_UserMathErrorFunction) __tailcall
