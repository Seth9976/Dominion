// 函数: __ehhandler$___dcrt_uninitialize_environments_nolock
// 地址: 0x76deb0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8ae78c, arg1, ecx_1) __tailcall
