// 函数: ?_CancelViaToken@_StructuredTaskCollection@details@Concurrency@@CAXPAV123@@Z
// 地址: 0x512890
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_570250(arg1) __tailcall
