// 函数: __ehhandler$??$initialize_tmpfile_buffer_nolock@_W@@YA_NW4buffer_id@?A0x5b9a7937@@@Z
// 地址: 0x76fa25
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffc0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bbf68, arg1, ecx_1) __tailcall
