// 函数: j_sub_52fb30
// 地址: 0x52fdc0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_52fb30(arg1) __tailcall
