// 函数: __unwindfunclet$?do_put@?$money_put@DV?$ostreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@MBE?AV?$ostreambuf_iterator@DU?$char_traits@D@std@@@2@V32@_NAAVios_base@2@DO@Z$0
// 地址: 0x7629a3
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4b3050(arg1 - 0x5c) __tailcall
