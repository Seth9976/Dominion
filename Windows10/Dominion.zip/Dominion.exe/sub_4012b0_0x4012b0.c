// 函数: sub_4012b0
// 地址: 0x4012b0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db538, "numCardsetCards")
data_8db538 = &UI2StateDeclInt::`vftable'{for `UI2StateDecl'}
return result
