// 函数: __ehhandler$?_CallInContext@_ContextCallback@details@Concurrency@@QBEXV?$function@$$A6AXXZ@std@@_N@Z
// 地址: 0x769a93
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b5888, arg1, ecx_1) __tailcall
