// 函数: __ehhandler$??$common_stat@U_stat64i32@@@@YAHQBDQAU_stat64i32@@@Z
// 地址: 0x76af6d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffd8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b7058, arg1, ecx_1) __tailcall
