// 函数: j_sub_536d70
// 地址: 0x53ab50
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_536d70() __tailcall
