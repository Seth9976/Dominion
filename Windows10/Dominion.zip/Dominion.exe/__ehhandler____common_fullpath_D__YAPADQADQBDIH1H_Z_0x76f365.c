// 函数: __ehhandler$??$common_fullpath@D@@YAPADQADQBDIH1H@Z
// 地址: 0x76f365
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffa0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bb7b4, arg1, ecx_1) __tailcall
