// 函数: ?_Copy@?$_Func_impl_no_alloc@V<lambda_ac2c1bfbb569343f806147a7f4de998c>@@XPAV?$message@I@Concurrency@@@std@@EBEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x506530
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_ceae1caa499d1d2ad0fea8452f71e5b0>, void>::`vftable'{for `std::_Func_base<void>'}
arg2[1] = *(arg1 + 4)
return arg2
