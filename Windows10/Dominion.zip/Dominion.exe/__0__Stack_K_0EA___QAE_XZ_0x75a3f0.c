// 函数: ??0?$Stack@K$0EA@@@QAE@XZ
// 地址: 0x75a3f0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

arg1[1] = 0
*arg1 = 0
arg1[2] = 0
return arg1
