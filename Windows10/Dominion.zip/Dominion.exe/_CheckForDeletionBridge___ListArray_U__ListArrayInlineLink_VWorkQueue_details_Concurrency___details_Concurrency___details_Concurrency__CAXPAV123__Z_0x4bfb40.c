// 函数: ?CheckForDeletionBridge@?$ListArray@U?$ListArrayInlineLink@VWorkQueue@details@Concurrency@@@details@Concurrency@@@details@Concurrency@@CAXPAV123@@Z
// 地址: 0x4bfb40
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4b8d80(arg1) __tailcall
