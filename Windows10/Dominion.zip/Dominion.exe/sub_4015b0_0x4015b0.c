// 函数: sub_4015b0
// 地址: 0x4015b0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db8e0, "img_avatar")
data_8db8e0 = &UI2StateDeclImage::`vftable'{for `UI2StateDecl'}
return result
