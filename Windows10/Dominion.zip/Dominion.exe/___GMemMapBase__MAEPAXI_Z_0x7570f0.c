// 函数: ??_GMemMapBase@@MAEPAXI@Z
// 地址: 0x7570f0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = &data_88ef20

if ((arg2 & 1) != 0)
    int32_t var_c_1 = 0xc
    operator new(arg1)

return arg1
