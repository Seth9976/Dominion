// 函数: ??2@YAPAXIHPBDH@Z
// 地址: 0x759661
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_7599be(arg1)
