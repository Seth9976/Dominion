// 函数: _CIfmod
// 地址: 0x76236e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _CIfmod() __tailcall
