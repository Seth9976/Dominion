// 函数: _initterm
// 地址: 0x762042
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _initterm(_First, _Last) __tailcall
