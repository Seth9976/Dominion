// 函数: ??1_Fac_node@std@@QAE@XZ
// 地址: 0x7591fd
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t* result = (*(**(arg1 + 4) + 8))()

if (result == 0)
    return result

return (**result)(1)
