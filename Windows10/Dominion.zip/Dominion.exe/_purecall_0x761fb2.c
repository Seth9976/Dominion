// 函数: _purecall
// 地址: 0x761fb2
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

noreturn _purecall() __tailcall
