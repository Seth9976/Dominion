// 函数: sub_401410
// 地址: 0x401410
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db7e8, "tutorial_disabled")
