// 函数: CookieCheckFunction
// 地址: 0x75927a
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t entry_ecx

if (entry_ecx != __security_cookie)
    noreturn ___report_gsfailure(arg1) __tailcall
