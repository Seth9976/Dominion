// 函数: _set_app_type
// 地址: 0x762030
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _set_app_type(_Type) __tailcall
