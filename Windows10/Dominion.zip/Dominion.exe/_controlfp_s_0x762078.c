// 函数: _controlfp_s
// 地址: 0x762078
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _controlfp_s(_CurrentState, _NewValue, _Mask) __tailcall
