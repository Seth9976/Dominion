// 函数: _exit
// 地址: 0x76204e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

noreturn _exit(_Except) __tailcall
