// 函数: __Init_thread_abort
// 地址: 0x759692
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

AcquireSRWLockExclusive(&data_cc8a08)
*arg1 = 0
ReleaseSRWLockExclusive(&data_cc8a08)
return WakeAllConditionVariable(&data_cc8a04)
