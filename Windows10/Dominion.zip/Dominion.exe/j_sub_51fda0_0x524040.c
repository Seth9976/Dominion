// 函数: j_sub_51fda0
// 地址: 0x524040
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_51fda0() __tailcall
