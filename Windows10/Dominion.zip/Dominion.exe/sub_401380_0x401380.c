// 函数: sub_401380
// 地址: 0x401380
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_4acb80(&data_8db77c, "gameCreateInvalid")
