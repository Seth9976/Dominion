// 函数: __ehhandler$??$set_variable_in_other_environment@D@@YA_NQBD0@Z
// 地址: 0x769c8d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffdc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b5a38, arg1, ecx_1) __tailcall
