// 函数: j_sub_507ad0
// 地址: 0x50a430
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_507ad0(arg1) __tailcall
