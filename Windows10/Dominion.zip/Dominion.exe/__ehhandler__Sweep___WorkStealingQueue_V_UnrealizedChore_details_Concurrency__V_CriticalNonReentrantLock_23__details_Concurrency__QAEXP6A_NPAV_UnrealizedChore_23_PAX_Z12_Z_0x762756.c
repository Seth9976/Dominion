// 函数: __ehhandler$?Sweep@?$WorkStealingQueue@V_UnrealizedChore@details@Concurrency@@V_CriticalNonReentrantLock@23@@details@Concurrency@@QAEXP6A_NPAV_UnrealizedChore@23@PAX@Z12@Z
// 地址: 0x762756
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8ae178, arg1, ecx_1) __tailcall
