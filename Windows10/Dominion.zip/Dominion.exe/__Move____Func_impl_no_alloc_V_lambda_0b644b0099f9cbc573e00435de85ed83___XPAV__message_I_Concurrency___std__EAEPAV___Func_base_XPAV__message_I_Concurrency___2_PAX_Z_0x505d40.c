// 函数: ?_Move@?$_Func_impl_no_alloc@V<lambda_0b644b0099f9cbc573e00435de85ed83>@@XPAV?$message@I@Concurrency@@@std@@EAEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x505d40
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_7ce5ca5ab40da0ec2d4dc68dc714695d>,bool,enum CardID>::`vftable'{for `std::_Func_base<bool,enum CardID>'}
arg2[1] = *(arg1 + 4)
return arg2
