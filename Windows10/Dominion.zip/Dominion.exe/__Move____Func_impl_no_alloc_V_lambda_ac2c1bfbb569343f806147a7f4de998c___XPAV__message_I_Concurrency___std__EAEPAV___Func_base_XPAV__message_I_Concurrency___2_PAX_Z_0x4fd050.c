// 函数: ?_Move@?$_Func_impl_no_alloc@V<lambda_ac2c1bfbb569343f806147a7f4de998c>@@XPAV?$message@I@Concurrency@@@std@@EAEPAV?$_Func_base@XPAV?$message@I@Concurrency@@@2@PAX@Z
// 地址: 0x4fd050
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = &std::_Func_impl_no_alloc<class <lambda_dad4450302e4a77d3fff40726c6a2caa>, void>::`vftable'{for `std::_Func_base<void>'}
arg2[1] = *(arg1 + 4)
return arg2
