// 函数: sub_401540
// 地址: 0x401540
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db8b0, "timeControl")
data_8db8b0 = &UI2StateDeclText::`vftable'{for `UI2StateDecl'}
return result
