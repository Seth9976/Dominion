// 函数: j_sub_5278d0
// 地址: 0x5287d0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_5278d0(arg1, arg2) __tailcall
