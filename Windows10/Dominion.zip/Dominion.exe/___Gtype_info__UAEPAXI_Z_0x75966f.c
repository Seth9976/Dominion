// 函数: ??_Gtype_info@@UAEPAXI@Z
// 地址: 0x75966f
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg1 = &type_info::`vftable'

if ((arg2 & 1) != 0)
    operator new(arg1)

return arg1
