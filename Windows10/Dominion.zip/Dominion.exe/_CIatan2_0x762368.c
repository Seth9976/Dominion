// 函数: _CIatan2
// 地址: 0x762368
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _CIatan2() __tailcall
