// 函数: __ehhandler$?_Tidy@ios_base@std@@AAEXXZ
// 地址: 0x76324d
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8af0e0, arg1, ecx_1) __tailcall
