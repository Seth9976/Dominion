// 函数: _controlfp
// 地址: 0x76207e
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _controlfp(_NewValue, _Mask) __tailcall
