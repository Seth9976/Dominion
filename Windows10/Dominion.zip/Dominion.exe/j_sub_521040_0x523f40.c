// 函数: j_sub_521040
// 地址: 0x523f40
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_521040(arg1) __tailcall
