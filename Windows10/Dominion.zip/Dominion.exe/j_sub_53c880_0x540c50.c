// 函数: j_sub_53c880
// 地址: 0x540c50
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return sub_53c880(arg1) __tailcall
