// 函数: __ehhandler$??$__acrt_lock_and_call@V<lambda_76b7ce3881063c72d9d9c3f590a24f96>@@@@YAHW4__acrt_lock_id@@$$QAV<lambda_76b7ce3881063c72d9d9c3f590a24f96>@@@Z
// 地址: 0x76fa65
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bbfd8, arg1, ecx_1) __tailcall
