// 函数: __ehhandler$?wait@?$ordered_message_processor@I@Concurrency@@UAEXXZ
// 地址: 0x764156
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffcc).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8b0008, arg1, ecx_1) __tailcall
