// 函数: ?do_unshift@?$codecvt@DDU_Mbstatet@@@std@@MBEHAAU_Mbstatet@@PAD1AAPAD@Z
// 地址: 0x63c640
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

*arg2 = arg1
return 3
