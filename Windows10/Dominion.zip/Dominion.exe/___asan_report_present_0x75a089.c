// 函数: ___asan_report_present
// 地址: 0x75a089
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result
result.b = data_8c40a0 != 0
return result
