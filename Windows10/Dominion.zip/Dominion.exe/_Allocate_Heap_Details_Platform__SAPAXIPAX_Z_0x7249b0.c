// 函数: ?Allocate@Heap@Details@Platform@@SAPAXIPAX@Z
// 地址: 0x7249b0
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return arg1
