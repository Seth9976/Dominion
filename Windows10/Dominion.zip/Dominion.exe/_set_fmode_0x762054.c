// 函数: _set_fmode
// 地址: 0x762054
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

return _set_fmode(_Value) __tailcall
