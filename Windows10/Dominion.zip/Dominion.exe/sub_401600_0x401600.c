// 函数: sub_401600
// 地址: 0x401600
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = sub_4acb80(&data_8db910, "recentFriendName")
data_8db910 = &UI2StateDeclText::`vftable'{for `UI2StateDecl'}
return result
