// 函数: __ehhandler$??$__acrt_lock_and_call@V<lambda_46720907175c18b6c9d2717bc0d2d362>@@@@YAXW4__acrt_lock_id@@$$QAV<lambda_46720907175c18b6c9d2717bc0d2d362>@@@Z
// 地址: 0x7724a5
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xffffffffffffffe8).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8bf0ac, arg1, ecx_1) __tailcall
