// 函数: __unwindfunclet$?SwitchTo@InternalContextBase@details@Concurrency@@IAEXPAV123@W4ReasonForSwitch@123@@Z$1
// 地址: 0x767b50
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t result = *(arg1 - 0x1c) & 1

if (result == 0)
    return result

*(arg1 - 0x1c) &= 0xfffffffe
return sub_63d770(arg1 - 0x50) __tailcall
