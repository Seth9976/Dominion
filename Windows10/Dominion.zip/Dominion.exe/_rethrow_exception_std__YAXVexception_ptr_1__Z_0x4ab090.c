// 函数: ?rethrow_exception@std@@YAXVexception_ptr@1@@Z
// 地址: 0x4ab090
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t var_8 = 0xffffffff
int32_t (* var_c)(struct EHRegistrationNode* arg1) =
    __ehhandler$??0?$basic_string@_WU?$char_traits@_W@std@@V?$allocator@_W@2@@std@@QAE@XZ
TEB* fsbase
struct _EXCEPTION_REGISTRATION_RECORD* ExceptionList = fsbase->NtTib.ExceptionList
int32_t __saved_ebp
int32_t var_14 = __security_cookie ^ &__saved_ebp
fsbase->NtTib.ExceptionList = &ExceptionList
int32_t result = `eh vector vbase constructor iterator'(arg1, 0xc, 0xf, sub_4ab1f0)
fsbase->NtTib.ExceptionList = ExceptionList
return result
