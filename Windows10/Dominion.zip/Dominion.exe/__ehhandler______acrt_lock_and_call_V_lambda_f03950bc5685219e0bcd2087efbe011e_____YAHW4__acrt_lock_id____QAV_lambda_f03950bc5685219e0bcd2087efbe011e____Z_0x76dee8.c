// 函数: __ehhandler$??$__acrt_lock_and_call@V<lambda_f03950bc5685219e0bcd2087efbe011e>@@@@YAHW4__acrt_lock_id@@$$QAV<lambda_f03950bc5685219e0bcd2087efbe011e>@@@Z
// 地址: 0x76dee8
// 来自: E:/Dominion/steamapps/common/Dominion/Dominion.exe.bndb

int32_t ecx_1 = arg1->__offset(0xfffffffffffffff0).d ^ &arg1[1]
CookieCheckFunction(&arg1[1])
return __CxxFrameHandler3(&data_8ba150, arg1, ecx_1) __tailcall
